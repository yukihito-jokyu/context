# 収束テスト ラウンド 2

convergence.py diff が生成する。揺れの分類（V1〜V8）と対処は dev/convergence-report.md に書く。

基準: status が全員、課題の expect_status（既定 done）と同じ。check が全員通過。スキル自身や hooks の登録を変えたエージェントがいない。files ≥ 1.0、structure ≥ 1.0、names ≥ 0.8

runner subagent は Agent ツールで実行した。一時プロジェクトの hooks は働かず、run.py の check と finish だけで検査された。自動の起動は、スキルの説明文を前置きで渡した近似である（convergence-test.md の3章）。

## 指標

| 課題 | status | files | structure | names | content | check | runner 別 files | 基準 |
|---|---|---|---|---|---|---|---|---|
| T1-typical | done | 0.875 | 0.429 | 0.223 | 0.711 | 全員通過 | subagent 0.875 | 満たさない |
| T2-default | done | 0.629 | 0.318 | 0.173 | 0.599 | 全員通過 | subagent 0.629 | 満たさない |
| T3-edge | done | 0.677 | 0.429 | 0.244 | 0.577 | 全員通過 | subagent 0.677 | 満たさない |

## T1-typical

### 実行の状態（期待: done）

- subagent-1: done
- subagent-2: done

### 新しく作った名前（names。先頭 40 件）

- subagent-1: `A-Z0-9_`, `ABC-12-subtract`, `ABC-34-subtract`, `ABC-56`, `Apple`, `Backlog`, `CHANGELOG`, `COMMIT_EDITMSG`, `CTL-02-builtin-hooks-claude`, `CTL-02-builtin-hooks-codex`, `Changing`, `Cloud`, `Co-Authored-By`, `Commit`, `CompletedProcess`, `Contributing`, `DESCRIPTION`, `Distributed`, `Edition`, `Fix`, `Fixes`, `Git`, `Git-155`, `Guidelines`, `HTTP`, `JRA-123`, `Jira`, `MAX_DESCRIPTION`, `NUL`, `OPTIONS`, `OUT-02-c`, `OUT-03-b`, `OUT-07`, `OUT-07-a`, `OUT-08`, `OUT-08-a`, `OUT-09`, `OUT-09-a`, `OUT-10`, `OUT-10-r1`
- subagent-2: `A-Z0-9_`, `A-Za-z`, `All`, `Alphabet`, `Apple`, `CHANGELOG`, `COMMIT_EDITMSG`, `CTL-02-builtin-hooks-claude`, `CTL-02-builtin-hooks-codex`, `Changing`, `Co-Authored-By`, `DIR`, `Exception`, `Git-155`, `GitError`, `GitLab`, `IDs`, `Jira`, `Modern`, `NUL`, `OPS-101`, `OUT-03-b`, `OUT-03-c`, `OUT-04-b`, `OUT-04-c`, `OUT-07`, `OUT-07-a`, `OUT-08`, `OUT-08-a`, `OUT-09`, `OUT-09-r1`, `Only`, `Otherwise`, `Redmine`, `Roman`, `STATUS`, `Same`, `Signed-off-by`, `Take`, `TypeError`

### 一部のエージェントだけが作った・変えたファイル

- `.claude/skills/write-commit-message/dev/fixtures/basic/notes.txt`: subagent-1
- `.claude/skills/write-commit-message/scripts/staged_changes.py`: subagent-1
- `.claude/skills/write-commit-message/scripts/staged_files.py`: subagent-2

### 中身の違い（抜粋）

#### `.claude/skills/write-commit-message/SKILL.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-commit-message/SKILL.md
+++ subagent-2/.claude/skills/write-commit-message/SKILL.md
@@ -1,12 +1,12 @@
 ---
 name: write-commit-message
-description: "ステージした変更とチケットIDを受け取り、チケットIDで始まる1行目と、変更ファイルごとの箇条書きの本文からなるコミットメッセージを出力する。「コミットメッセージを書いて。チケットIDで始まる1行目と、変更ファイルごとの箇条書きの本文にしたい」、「ステージした変更のコミットメッセージを作成してください」、「この差分でコミットメッセージ考えて」、「チケット ABC-123 の作業をコミットするので、メッセージをお願いします」、「Write a commit message for my staged changes」と頼まれたときに使う。プルリクエストの説明文を書くには使わない（代わりにプルリクエストの説明を書くスキル、または直接の依頼を使う）。変更履歴（CHANGELOG）の節を書くには使わない（代わりに変更履歴を書くスキル、または直接の依頼を使う）。"
+description: "ステージした変更とチケットIDから、チケットIDで始まる1行目と変更ファイルごとの箇条書きの本文を持つコミットメッセージを書く。「コミットメッセージを書いて」、「ステージした変更のコミットメッセージを考えて」、「チケットIDを付けてコミットメッセージを作成してください」、「この変更、commit message にまとめて」、「変更ファイルごとに箇条書きでコミットの本文を書いて」、「Write a commit message for the staged changes」と頼まれたときに使う。プルリクエストの説明文を書くには使わない（代わりにプルリクエストの説明を書く別のスキルか、スキルを使わない直接の依頼を使う）。変更履歴（CHANGELOG）の節を書くには使わない（代わりに変更履歴を書く別のスキルか、スキルを使わない直接の依頼を使う）。既にあるコミットのメッセージを書き換える（rebase、amend）には使わない（代わりに`git rebase -i` か `git commit --amend`を使う）。"
 ---
 
 # コミットメッセージを書く
 
 <!-- BEGIN GENERATED:purpose -->
-ステージした変更とチケットIDを受け取り、チケットIDで始まる1行目と、変更ファイルごとの箇条書きの本文からなるコミットメッセージを出力する
+ステージした変更とチケットIDから、チケットIDで始まる1行目と変更ファイルごとの箇条書きの本文を持つコミットメッセージを書く
 <!-- END GENERATED:purpose -->
 
 ## 1. 使う場面
@@ -14,16 +14,18 @@
 <!-- BEGIN GENERATED:triggers -->
 次のような依頼で使う。
 
-- 「コミットメッセージを書いて。チケットIDで始まる1行目と、変更ファイルごとの箇条書きの本文にしたい」
-- 「ステージした変更のコミットメッセージを作成してください」
-- 「この差分でコミットメッセージ考えて」
-- 「チケット ABC-123 の作業をコミットするので、メッセージをお願いします」
-- 「Write a commit message for my staged changes」
+- 「コミットメッセージを書いて」
+- 「ステージした変更のコミットメッセージを考えて」
+- 「チケットIDを付けてコミットメッセージを作成してください」
+- 「この変更、commit message にまとめて」
+- 「変更ファイルごとに箇条書きでコミットの本文を書いて」
+- 「Write a commit message for the staged changes」
 
 次の場合は使わない。
 
-- プルリクエストの説明文を書く → 代わりに: プルリクエストの説明を書くスキル、または直接の依頼
-- 変更履歴（CHANGELOG）の節を書く → 代わりに: 変更履歴を書くスキル、または直接の依頼
+- プルリクエストの説明文を書く → 代わりに: プルリクエストの説明を書く別のスキルか、スキルを使わない直接の依頼
+- 変更履歴（CHANGELOG）の節を書く → 代わりに: 変更履歴を書く別のスキルか、スキルを使わない直接の依頼
+- 既にあるコミットのメッセージを書き換える（rebase、amend） → 代わりに: `git rebase -i` か `git commit --amend`
 
 依頼の内容から自動で選ばれる。明示して呼ぶときは Claude Code では `/write-commit-message`、Codex では `$write-commit-message` と書く。
 <!-- END GENERATED:triggers -->
@@ -32,19 +34,21 @@
 
 このファイルがあるディレクトリを `<skill>` と呼ぶ。スクリプトは Python 3.9 以上の標準ライブラリだけで動く。手順は番号の順に行い、飛ばさない。
 
-1. `python3 <skill>/scripts/staged_changes.py collect` を実行する。終了コードが 2・4・5 なら、IN-01 の表の返答をして終える（start も出力もしない）。終了コードが0なら、依頼から「3. 入力」のチケットID（`ticket`）を読み取り、依頼に無ければ OUT-05 の表で決める。表が「聞く」になったら、ここでユーザーに聞く（CTL-03）
+1. 依頼から「3. 入力」の項目を読み取る。チケットID（`ticket`）が依頼に無ければ、ここでユーザーに聞く（CTL-03）
 2. `python3 <skill>/scripts/run.py start --set ticket=<チケットID> "<依頼文>"` を実行する。終了コード3なら、出力された質問をユーザーに聞き、答えを `--set` で渡してやり直す（CTL-01）
-3. 手順1の `collect` の出力の「本文の行」と「差分」だけを材料にする。ステージしていない変更、`git log`、差分に出ないファイルの全文を読まない（IN-02、STEP-01）。`git commit`、`git add`、`git rm`、`git mv`、`git reset`、`git restore`、`git stash` を実行しない（STEP-02）
-4. 見本 `<skill>/assets/examples/commit-message.txt` を写す元にして、`.skill-runs/write-commit-message/out/commit-message.txt` を書く（OUT-01）。1行目は `<チケットID> <要約>` で 50 文字以下、2行目は空行にする（OUT-02、OUT-05、OUT-06）。3行目からは「本文の行」を同じ順に1行ずつ写し、`: ` の後に 40 文字以下の説明を足す（OUT-03、OUT-07）。要約と説明は日本語の「〜する」の形で終え、差分に現れる変更だけを書く（OUT-04、OUT-10）。CI を止める記法、URL、本文のチケットIDを書かない（OUT-08、OUT-09）
-5. `python3 <skill>/scripts/run.py check` を実行する。指摘があれば、ルールIDを「4. 決定表」で引いて出力を直す。検査や契約を変えて通さない（CTL-02）
-6. 決めきれなかったことがあれば `.skill-runs/write-commit-message/notes.md` に「- 」の箇条書きで書き、`python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順5に戻る。終了コード0なら、出力された本文をそのまま返答する（RPT-01）
+3. `python3 <skill>/scripts/staged_files.py list` を実行する。終了コードが0でなければ、IN-01 の表のとおり `python3 <skill>/scripts/run.py abort --reason <理由>` で中断し、abort が出力した本文をそのまま返答して終える。ステージした変更が無くても `git add` を実行しない（IN-01）
+4. `git diff --cached -M` を実行し、ステージした差分を読む。ステージしていない変更（`git diff`）、追跡していないファイル、`git log`、チケットの中身は読まない（IN-02）
+5. 見本 `assets/examples/commit-message.txt` を写す元にして、`.skill-runs/write-commit-message/out/commit-message.txt` に書く（OUT-01）。1行目は `<チケットID> <要約>` で50文字以下にし（OUT-02、OUT-05）、2行目は空行にし、3行目からは手順3の一覧の順に「行の頭」と説明を1ファイル1行で書く（OUT-03、OUT-06）。要約と説明は動詞の終止形で終え（OUT-04）、説明にはそのファイルの差分で変わったことだけを書く（OUT-09）。URL と CI を止める記法は書かない（OUT-07、OUT-08）
+6. `python3 <skill>/scripts/run.py check` を実行する。指摘があれば、ルールIDを「4. 決定表」で引いて出力を直す。検査や契約を変えて通さない（CTL-02）
+7. `git add`、`git commit`、`git push`、`git stash`、`git reset` は実行しない。コミットのコマンドは finish の報告の「## コミットのしかた」に出るので、利用者に任せる（STEP-01）
+8. 決めきれなかったことがあれば `.skill-runs/write-commit-message/notes.md` に「- 」の箇条書きで書き、`python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順6に戻る。終了コード0なら、出力された本文をそのまま返答する（RPT-01）
```

#### `.claude/skills/write-commit-message/assets/contract.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-commit-message/assets/contract.json
+++ subagent-2/.claude/skills/write-commit-message/assets/contract.json
@@ -15,16 +15,17 @@
       "case": "upper",
       "aliases": [
         "チケット",
+        "チケットID",
         "チケット番号",
         "課題キー",
         "課題",
+        "ticket id",
         "issue",
-        "issue key",
-        "ticket id"
+        "issue key"
       ],
       "impact": "target",
       "ask": true,
-      "question": "コミットに付けるチケットIDを教えてください（例: ABC-123）"
+      "question": "コミットのチケットID（例：ABC-123）は何ですか"
     }
   ],
   "outputs": [
@@ -40,96 +41,73 @@
       "format": [
         {
           "type": "trailing_space",
-          "rule": "OUT-02"
+          "rule": "OUT-04"
         },
         {
-          "type": "final_newline",
-          "rule": "OUT-02"
+          "type": "replace",
+          "pattern": "[。．]+$",
+          "with": "",
+          "rule": "OUT-04",
+          "message": "行末の「。」「．」を消しました"
         }
       ],
       "checks": [
         {
-          "rule": "OUT-05",
           "type": "require",
-          "pattern": "^{in:ticket} ",
+          "pattern": "^{in:ticket} \\S",
           "lines": "first",
-          "message": "1行目は入力 ticket のチケットIDと半角の空白1つで始める"
+          "rule": "OUT-02",
+          "message": "1行目は `<チケットID> <要約>` の形にし、チケットIDに括弧とコロンを付けない"
         },
         {
+          "type": "forbid",
+          "pattern": "^{in:ticket} [A-Za-z]+(\\([^)]*\\))?!?: ",
+          "lines": "first",
           "rule": "OUT-02",
-          "type": "require",
-          "pattern": "^\\S+ \\S",
-          "lines": "first",
-          "message": "1行目は `<チケットID> <要約>` の形にし、間は半角の空白1つにする"
```

#### `.claude/skills/write-commit-message/assets/examples/commit-message.txt`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-commit-message/assets/examples/commit-message.txt
+++ subagent-2/.claude/skills/write-commit-message/assets/examples/commit-message.txt
@@ -1,5 +1,4 @@
-ABC-12 引き算の関数と使い方の説明を足す
+ABC-12 計算モジュールに引き算を足す
 
-- README.md: 引き算の使い方を足す
-- notes.txt -> docs/notes.txt: 作業のメモを docs の下に移す
 - src/calc.py: 引き算の関数 subtract を足す
+- tests/test_calc.py: subtract のテストを足す
```

#### `.claude/skills/write-commit-message/assets/seal.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-commit-message/assets/seal.json
+++ subagent-2/.claude/skills/write-commit-message/assets/seal.json
@@ -1,14 +1,14 @@
 {
   "runtime": "1.0.0",
   "files": {
-    "SKILL.md": "3f4fc0f0f5d936c576b10242f0ba85c06d0dfae933124772a992a171ef246cff",
-    "assets/contract.json": "cf4c9a147abd7499b8e58cd1c8ab81c05cfdfe96b318f5e7dc25941ec3900aaf",
-    "assets/examples/commit-message.txt": "80c6efc333a0d85c9f77f9cdbaba24e74e4735466d7b1fc2a2c56cf93c503c82",
-    "references/decisions.md": "62dcb5da138e62a5adb8826b92ca3f09c6c71f025108c8360bec81537fb775e3",
+    "SKILL.md": "588a1bc35485329bcae0b2d7bb3ec836462ffa136c0e8827982c3f180261dc25",
+    "assets/contract.json": "65295ee1ecc2e975bdd38016de397c12dedfaa1f0117ae834c10adedba97dd75",
+    "assets/examples/commit-message.txt": "9a9bc1ece027d7543399985238ff13b20cc6498f779922e7b0d340f148947b03",
+    "references/decisions.md": "8893654dedb5d63af1f6729a16c379fda9bf2938d9f68644d69fdf348c049031",
     "scripts/run.py": "fcced04ce88880bbe860dadc1d25481c464f13d733de4d4c7d9c5ccbde096b76",
     "scripts/_skillrt.py": "b76eceeda4fdcad10a4246a66a7d137d2400cec49cc62d95ec89fd463b784304",
+    "scripts/staged_files.py": "cea303d59c741dfd16647992b2f0af5d222910225dc81f18015b63d9e79addee",
     "scripts/hook.py": "b0ccd614d242fcbbd2499da75d759b33b4cb8f7c7357563954570f15c3a7ef55",
-    "scripts/staged_changes.py": "e92e75e2860a84e6e395b5eed8345542df9629f36ab809a677b07aaa5029a162",
     "scripts/install.py": "286effaa9680fd4f8a03816b37252e36b62172301ef9d64c8debd4646d91ea19"
   }
 }
```

#### `.claude/skills/write-commit-message/dev/convergence-report.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-commit-message/dev/convergence-report.md
+++ subagent-2/.claude/skills/write-commit-message/dev/convergence-report.md
@@ -1,14 +1,14 @@
 # write-commit-message 収束テストの記録
 
-このスキルの作成に関わっていない独立エージェント（Claude Code と Codex。起動できないときは Agent ツールの subagent）に同じ依頼を解かせ、出力の違い（揺れ）を測った記録である。生データは `dev/results/convergence/round-<R>/` にある。
+このスキルの作成に関わっていない独立エージェントに同じ依頼を解かせ、出力の違い（揺れ）を測る記録である。今回は収束テストを実行していない。
 
 ## 条件
 
 | 項目 | 値 |
 |---|---|
-| runner | 実行しない。skill-foundation の入力 `measure` が `skip`（利用者が「収束テストは省いて」と指定した）なので、STEP-02 の表で実行しないことになった |
+| runner | なし。skill-foundation の入力 `measure` が `skip` だったため、STEP-02 の表の skip の行に従い、runner を決めずに省いた |
 | 1 runner あたりの人数 | なし |
-| 課題 | `dev/evals.json`（4件。実行していない） |
+| 課題 | `dev/evals.json`（T1-typical、T2-default、T3-edge、H1-holdout。実行していない） |
 | 合格基準 | status が全員、課題の expect_status と同じ。check が全員通過。スキル自身や hooks の登録を変えたエージェント（失格）がいない。files・structure・names が基準以上。最後のラウンドのレビューの検出率が全見本で 1.0。V1〜V7 の未対処が0件 |
 
 ## ラウンドの一覧
@@ -21,8 +21,8 @@
 
 | 見本 | 決定 | 検出率 | 余計な指摘 | 一致 |
 |---|---|---|---|---|
-| `OUT-10-r1` | `OUT-10` | 測っていない（収束テストを省いた） | | |
+| `OUT-09-r1` | OUT-09 | 測っていない | | |
 
 ## 結論
 
-収束テストは、利用者の指定で実行していない（spec の `convergence.skip_reason`：「利用者が収束テストを省くと指定した」）。独立エージェントの間で出力が揃うか、`OUT-10`（説明が差分と合っているか）のレビューの検出率は確かめていない。機械の検査と違反例は `probe.py` で確かめた（probe 25 件・配線 20 件がすべて成功）。
+収束テストは、利用者が省くと指定したため実行していない（spec の `convergence.skip_reason`）。決定を機械で守らせる仕組みは `probe.py` で確かめた（違反例 13 件、レビューの見本 1 件、標準の確認 12 件、hooks の配線 20 件がすべて成功）。別の AI が同じ依頼から同じ出力を作るか、レビューの見本 `OUT-09-r1` を完了前チェックリストで見つけられるかは、測っていない。
```

#### `.claude/skills/write-commit-message/dev/evals.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-commit-message/dev/evals.json
+++ subagent-2/.claude/skills/write-commit-message/dev/evals.json
@@ -3,12 +3,11 @@
     {
       "id": "T1-typical",
       "kind": "typical",
-      "prompt": "ABC-12 のコミットメッセージを書いて。ステージ済みの変更が対象です",
+      "prompt": "ABC-12 のコミットメッセージを書いて",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "printf '\\ndef subtract(a, b):\\n    return a - b\\n' >> src/calc.py",
-        "printf '\\n引き算は subtract(a, b) で行う。\\n' >> README.md",
-        "mkdir -p docs && git mv notes.txt docs/notes.txt",
+        "printf '\\n\\ndef subtract(a, b):\\n    return a - b\\n' >> src/calc.py",
+        "mkdir -p tests && printf 'from src.calc import subtract\\n\\n\\ndef test_subtract():\\n    assert subtract(3, 1) == 2\\n' > tests/test_calc.py",
         "git add -A"
       ],
       "expect_status": "done"
@@ -16,12 +15,10 @@
     {
       "id": "T2-default",
       "kind": "default",
-      "prompt": "ステージした変更のコミットメッセージを考えて",
+      "prompt": "calc-7 でコミットメッセージお願い",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "git checkout -q -b feature/ABC-34-subtract",
-        "printf '\\ndef subtract(a, b):\\n    return a - b\\n' >> src/calc.py",
-        "printf '\\n引き算は subtract(a, b) で行う。\\n' >> README.md",
+        "printf '\\n## 使い方\\n\\n`from src.calc import add` で読み込む。\\n' >> README.md",
         "git add -A"
       ],
       "expect_status": "done"
@@ -29,23 +26,21 @@
     {
       "id": "T3-edge",
       "kind": "edge",
-      "prompt": "ABC-56 のコミットメッセージを書いて",
+      "prompt": "ABC-30 のコミットメッセージを書いてください",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "printf '\\ndef subtract(a, b):\\n    return a - b\\n' >> src/calc.py",
-        "printf '\\n引き算は subtract(a, b) で行う。\\n' >> README.md"
+        "printf '\\n開発中のメモ。\\n' >> README.md"
       ],
-      "expect_status": "unused"
+      "expect_status": "aborted"
     },
     {
       "id": "H1-holdout",
       "kind": "holdout",
-      "prompt": "XYZ-7 でコミットするので、メッセージを作成してください",
+      "prompt": "OPS-101 の変更をコミットしたいので、メッセージを作成してください",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "git rm -q notes.txt",
-        "printf 'def mean(values):\\n    return sum(values) / len(values)\\n' > src/stats.py",
-        "git add -A"
+        "git mv src/calc.py src/arith.py",
+        "git rm -q README.md"
```


## T2-default

### 実行の状態（期待: done）

- subagent-1: done
- subagent-2: done

### 新しく作った名前（names。先頭 40 件）

- subagent-1: `Added`, `All`, `Apple`, `BREAKING`, `BREAKING_TYPES`, `BREAKING_WORDS`, `Breaking`, `CHANGE`, `CHANGELOG`, `CHANGELOG_ENTRY`, `CITATION`, `CTL-02-builtin-hooks-claude`, `CTL-02-builtin-hooks-codex`, `Changed`, `Copied`, `Deleted`, `Deprecated`, `ENDINGS`, `FILE_UNIT_MAX`, `Git-155`, `HTTP`, `LABEL`, `Mark`, `Modified`, `NUL`, `New`, `OUT-02-c`, `OUT-03-b`, `OUT-04-b`, `OUT-04-r1`, `OUT-07`, `OUT-07-a`, `OUT-07-b`, `OUT-08`, `OUT-08-a`, `OUT-08-r1`, `PurePosixPath`, `R100`, `Removed`, `Renamed`
- subagent-2: `ALICE`, `Added`, `Alice`, `All`, `Apple`, `Bob`, `CHANGELOG`, `CHECK_PARTS`, `CTL-02-builtin-hooks-claude`, `CTL-02-builtin-hooks-codex`, `Changed`, `Changelogs`, `Deprecated`, `EOF`, `EXIT_EMPTY`, `EXIT_ERROR`, `EXIT_INTERNAL`, `Exception`, `Failure`, `GIT`, `GREET_NAME`, `Git-155`, `HELLO`, `Hello`, `INTERNAL_FILES`, `INTERNAL_NAME`, `INTERNAL_PARTS`, `INTERNAL_PREFIXES`, `IndexError`, `JA_CHAR`, `MAX_ITEMS`, `NUL`, `OUT-04-b`, `OUT-04-r1`, `OUT-07`, `OUT-07-a`, `OUT-07-b`, `OUT-08`, `OUT-09`, `OUT-09-a`

### 一部のエージェントだけが作った・変えたファイル

- `.claude/skills/write-changelog-entry/dev/fixtures/basic/greet/__init__.py`: subagent-2
- `.claude/skills/write-changelog-entry/dev/fixtures/basic/greet/cli.py`: subagent-2
- `.claude/skills/write-changelog-entry/dev/fixtures/basic/greet/core.py`: subagent-2
- `.claude/skills/write-changelog-entry/dev/fixtures/basic/src/app.py`: subagent-1
- `.claude/skills/write-changelog-entry/dev/fixtures/basic/src/util.py`: subagent-1
- `.claude/skills/write-changelog-entry/dev/fixtures/basic/tests/test_core.py`: subagent-2
- `.skill-runs/skill-foundation/work/basic.patch`: subagent-2
- `.skill-runs/skill-foundation/work/decisions.py`: subagent-2
- `.skill-runs/skill-foundation/work/h1.patch`: subagent-2
- `.skill-runs/skill-foundation/work/outputs.py`: subagent-2
- `.skill-runs/skill-foundation/work/probes.py`: subagent-2
- `.skill-runs/skill-foundation/work/t2.patch`: subagent-2
- `.skill-runs/skill-foundation/work/t3.patch`: subagent-2

### 中身の違い（抜粋）

#### `.claude/skills/write-changelog-entry/SKILL.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-changelog-entry/SKILL.md
+++ subagent-2/.claude/skills/write-changelog-entry/SKILL.md
@@ -1,12 +1,12 @@
 ---
 name: write-changelog-entry
-description: "ステージ済みの差分から、変更履歴（CHANGELOG.md）に足す1節を書く。「変更履歴（CHANGELOG.md）に足す1節を、ステージ済みの差分から書いて」、「ステージした変更から CHANGELOG の項目を作って」、「この変更を CHANGELOG.md の Unreleased に書き足す文を考えて」、「今回の変更の変更履歴を書いてほしい」、「changelog entry 書いて」、「Write a CHANGELOG entry for the staged changes」と頼まれたときに使う。コミットメッセージを書くには使わない（代わりにコミットメッセージ用のスキルを使う）。リリースの実行（バージョン番号の決定、タグ付け、公開）には使わない（代わりにリリースの手順と git コマンドを使う）。過去のコミット履歴全体から CHANGELOG.md を作り直すには使わない（代わりに`git log` を読んでまとめる手作業を使う）。"
+description: "ステージ済みの差分（git diff --cached）を受け取り、CHANGELOG.md の「## [Unreleased]」として足す1節を Keep a Changelog の形で書く。「変更履歴（CHANGELOG.md）に足す1節を、ステージ済みの差分から書いて」、「ステージした変更から CHANGELOG のエントリを作ってください」、「git add した差分をもとに、CHANGELOG.md の Unreleased に追記する文を書いて」、「今回ステージした修正を変更履歴に追記しておいて」、「Write a changelog entry from the staged changes」、「CHANGELOG 更新して。差分はもうステージしてある」と頼まれたときに使う。コミットメッセージを書く依頼には使わない（代わりにコミットメッセージを書く手順（このスキルは CHANGELOG.md の1節だけを書く）を使う）。版を付けてリリースする依頼（「## [Unreleased]」を版の見出しに変える、タグを打つ）には使わない（代わりにプロジェクトのリリースの手順を使う）。タグ間やコミット履歴の全体から変更履歴をまとめて作り直す依頼には使わない（代わりにその作業を直接行う（このスキルはステージ済みの差分だけを材料にする）を使う）。"
 ---
 
-# 変更履歴の1節を書く
+# ステージ済みの差分から変更履歴の1節を書く
 
 <!-- BEGIN GENERATED:purpose -->
-ステージ済みの差分から、変更履歴（CHANGELOG.md）に足す1節を書く
+ステージ済みの差分（git diff --cached）を受け取り、CHANGELOG.md の「## [Unreleased]」として足す1節を Keep a Changelog の形で書く
 <!-- END GENERATED:purpose -->
 
 ## 1. 使う場面
@@ -15,17 +15,17 @@
 次のような依頼で使う。
 
 - 「変更履歴（CHANGELOG.md）に足す1節を、ステージ済みの差分から書いて」
-- 「ステージした変更から CHANGELOG の項目を作って」
-- 「この変更を CHANGELOG.md の Unreleased に書き足す文を考えて」
-- 「今回の変更の変更履歴を書いてほしい」
-- 「changelog entry 書いて」
-- 「Write a CHANGELOG entry for the staged changes」
+- 「ステージした変更から CHANGELOG のエントリを作ってください」
+- 「git add した差分をもとに、CHANGELOG.md の Unreleased に追記する文を書いて」
+- 「今回ステージした修正を変更履歴に追記しておいて」
+- 「Write a changelog entry from the staged changes」
+- 「CHANGELOG 更新して。差分はもうステージしてある」
 
 次の場合は使わない。
 
-- コミットメッセージを書く → 代わりに: コミットメッセージ用のスキル
-- リリースの実行（バージョン番号の決定、タグ付け、公開） → 代わりに: リリースの手順と git コマンド
-- 過去のコミット履歴全体から CHANGELOG.md を作り直す → 代わりに: `git log` を読んでまとめる手作業
+- コミットメッセージを書く依頼 → 代わりに: コミットメッセージを書く手順（このスキルは CHANGELOG.md の1節だけを書く）
+- 版を付けてリリースする依頼（「## [Unreleased]」を版の見出しに変える、タグを打つ） → 代わりに: プロジェクトのリリースの手順
+- タグ間やコミット履歴の全体から変更履歴をまとめて作り直す依頼 → 代わりに: その作業を直接行う（このスキルはステージ済みの差分だけを材料にする）
 
 依頼の内容から自動で選ばれる。明示して呼ぶときは Claude Code では `/write-changelog-entry`、Codex では `$write-changelog-entry` と書く。
 <!-- END GENERATED:triggers -->
@@ -34,18 +34,22 @@
 
 このファイルがあるディレクトリを `<skill>` と呼ぶ。スクリプトは Python 3.9 以上の標準ライブラリだけで動く。手順は番号の順に行い、飛ばさない。
 
-1. このスキルには start の前にユーザーに聞く入力が無いので、質問せずに進む（CTL-03）。依頼文に版の番号か日付があれば、IN-01 の表の2行目に従う
-2. `python3 <skill>/scripts/run.py start "<依頼文>"` を実行する（CTL-01）
-3. `python3 <skill>/scripts/changelog_entry.py collect` を実行する。終了コード4なら IN-01、終了コード2なら STEP-04 に従って中断する。材料は出力の「単位」の表と差分だけにし、未ステージの変更、`git log`、既存の CHANGELOG.md を読まない。git はこのスクリプトの中だけで使い、`git add`・`git commit` を実行しない（IN-02、STEP-01、STEP-03）
-4. 「単位」の表の単位ごとに、OUT-04 の表で種類を決める。「許す種類」が1つだけの単位は、その種類の項目を1つだけ書く。「許す種類」が6つの単位は、差分が当たる表の行ごとに1つの項目を書く。Changed と Removed の項目は、OUT-08 の表で `**Breaking:** ` を付けるかを決める（STEP-02、OUT-04、OUT-08）
-5. 見本 `assets/examples/changelog-entry.md` と同じ形で節を書き、`.skill-runs/write-changelog-entry/out/changelog-entry.md` に保存する。1行目は `## [Unreleased]`、2行目は空行にし、種類の見出しを OUT-02 の順に並べる。項目は「- <日本語の文><種類の語>（`<単位>`）」の1行（100文字以内）にし、同じ種類の中は単位のパスの昇順に並べる。CHANGELOG.md は書き換えない（OUT-01、OUT-02、OUT-03、OUT-05、OUT-06、OUT-07）
-6. `python3 <skill>/scripts/run.py check` を実行する。「整形」で始まる行は check が契約の format で自動で直した記録なので、ファイルを読み直す。指摘があれば、ルールIDを「4. 決定表」で引いて出力を直す。検査や契約を変えて通さない（CTL-02）
-7. 決めきれなかったことがあれば `.skill-runs/write-changelog-entry/notes.md` に「- 」の箇条書きで書き、`python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順6に戻る。終了コード0なら、出力された本文をそのまま返答する。CHANGELOG.md への写し方は、本文の「## CHANGELOG.md への写し方」に入っている（RPT-01、OUT-06）
+1. 依頼から「3. 入力」の項目を読み取る。表で「start の前に聞く」とある項目が依頼に無ければ、ここでまとめてユーザーに聞く（CTL-03）
+2. `python3 <skill>/scripts/run.py start "<依頼文>"` を実行する。依頼に項目の言語の指定があるときだけ `--set language=<ja か en>` を足す。終了コード3なら、出力された質問をユーザーに聞き、答えを `--set` で渡してやり直す（CTL-01）
+3. `python3 <skill>/scripts/changelog_entry.py collect` を実行する。終了コードが2、4、5のどれかなら、IN-01 の表の理由で `python3 <skill>/scripts/run.py abort --reason <理由>` を実行し、abort が出力した本文をそのまま返答して終える。1節の材料は collect の出力だけにする（IN-02）。STEP-02 に挙げた、ステージの状態を変えるコマンドを実行しない（STEP-02）
+4. collect の「対象」の差分を、利用者から見た変更1つずつに分け、変更ごとに STEP-01 の表で種類を決める。すべての変更が「書かない」に当たったら、IN-01 の表のとおり `run.py abort` を実行して終える
+5. 見本 `assets/examples/changelog-entry.md` と同じ形で、`.skill-runs/write-changelog-entry/out/changelog-entry.md` に1節を書く（OUT-01）。行の形は OUT-02、言語は collect の「言語」の値（OUT-03）、文末と用語は OUT-04、種類の並びは OUT-05、項目の並びは OUT-06、項目の数は collect の「項目数の上限」以下（OUT-07）にし、ファイルのパスと番号を書かない（OUT-09）。CHANGELOG.md は作らず、書き換えない（OUT-08）
```

#### `.claude/skills/write-changelog-entry/assets/contract.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-changelog-entry/assets/contract.json
+++ subagent-2/.claude/skills/write-changelog-entry/assets/contract.json
@@ -7,78 +7,121 @@
     "claude",
     "codex"
   ],
-  "inputs": [],
+  "inputs": [
+    {
+      "key": "language",
+      "label": "項目の言語",
+      "type": "enum",
+      "enum": [
+        "ja",
+        "en"
+      ],
+      "enum_aliases": {
+        "日本語": "ja",
+        "japanese": "ja",
+        "英語": "en",
+        "english": "en"
+      },
+      "case": "lower",
+      "aliases": [
+        "言語",
+        "lang",
+        "出力の言語"
+      ],
+      "impact": "optional"
+    }
+  ],
   "outputs": [
     {
-      "id": "entry",
-      "label": "変更履歴の1節",
+      "id": "changelog-entry",
+      "label": "CHANGELOG.md に足す1節",
       "path": "{run}/out/changelog-entry.md",
       "rule": "OUT-01",
       "count": {
         "min": 1,
         "max": 1
       },
+      "format": [
+        {
+          "type": "command",
+          "rule": "OUT-02",
+          "run": "python3 {skill}/scripts/changelog_entry.py fix {file} --part headings",
+          "message": "見出し、項目の記号、行末を Keep a Changelog の形に整えました"
+        },
+        {
+          "type": "command",
+          "rule": "OUT-05",
+          "run": "python3 {skill}/scripts/changelog_entry.py fix {file} --part types",
+          "message": "種類の見出しを Added、Changed、Deprecated、Removed、Fixed、Security の順に並べ替えました"
+        },
+        {
+          "type": "command",
+          "rule": "OUT-06",
+          "run": "python3 {skill}/scripts/changelog_entry.py fix {file} --part items",
```

#### `.claude/skills/write-changelog-entry/assets/examples/changelog-entry.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-changelog-entry/assets/examples/changelog-entry.md
+++ subagent-2/.claude/skills/write-changelog-entry/assets/examples/changelog-entry.md
@@ -2,13 +2,9 @@
 
 ### Added
 
-- 計算結果の見出しの設定 `LABEL` を追加（`src/config.py`）
-- 引き算の関数 `sub` を追加（`src/util.py`）
+- `GREET_NAME` 環境変数で、名前を省いたときに使う名前を決められるようにした。
+- 挨拶を大文字で表示する `--shout` オプションを足した。
 
-### Changed
+### Fixed
 
-- 計算結果の表示に見出しを付ける形に変更（`src/app.py`）
-
-### Removed
-
-- **Breaking:** 掛け算の関数 `mul` を削除（`src/util.py`）
+- 名前を空にして実行すると、挨拶を表示せずに止まる不具合を直した。
```

#### `.claude/skills/write-changelog-entry/assets/seal.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-changelog-entry/assets/seal.json
+++ subagent-2/.claude/skills/write-changelog-entry/assets/seal.json
@@ -1,14 +1,14 @@
 {
   "runtime": "1.0.0",
   "files": {
-    "SKILL.md": "e45f4594e3a92fa7407b4456650b44ccbf6b5c1e1554fbb78d97b11498739ff5",
-    "assets/contract.json": "e594b7da6f76247873cdce21da45315af3a3686a52d02e05222fe5472d4cc6bf",
-    "assets/examples/changelog-entry.md": "e5e4c392b40fd0e3c764028e5c17c129082c7c13c1675010c9ed5d1e582bca4f",
-    "references/decisions.md": "81d00d8cc3623d30dde6c258670cb1e8e70c1f9302e3c18c5ffac4993da927a3",
+    "SKILL.md": "21563f2d107e4c82fc3068ad580649e4d5728523358a9b55bab26a8620263f55",
+    "assets/contract.json": "54243e71bc00b2ea5ddfa70fba1ac26a063e7ddfaa0107f9571dfed53c2e08dc",
+    "assets/examples/changelog-entry.md": "92b5e8e238b36bada34dbc134521630a76a35afac9453ed1a70f2df59322135c",
+    "references/decisions.md": "2ee4d506b9bb5828b751a4881e29d19c2b96f59526285bb5bf631fb61a774424",
     "scripts/run.py": "fcced04ce88880bbe860dadc1d25481c464f13d733de4d4c7d9c5ccbde096b76",
     "scripts/_skillrt.py": "b76eceeda4fdcad10a4246a66a7d137d2400cec49cc62d95ec89fd463b784304",
     "scripts/hook.py": "b0ccd614d242fcbbd2499da75d759b33b4cb8f7c7357563954570f15c3a7ef55",
-    "scripts/changelog_entry.py": "c4a9587e2036220866ec160a459d45d1f790661777b3425ccb93ee0f6aac9f98",
+    "scripts/changelog_entry.py": "24c070071b1f98ce1d73883b4dea9086207035d5e2251fa46b385a900e6eb1a5",
     "scripts/install.py": "286effaa9680fd4f8a03816b37252e36b62172301ef9d64c8debd4646d91ea19"
   }
 }
```

#### `.claude/skills/write-changelog-entry/dev/convergence-report.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-changelog-entry/dev/convergence-report.md
+++ subagent-2/.claude/skills/write-changelog-entry/dev/convergence-report.md
@@ -1,28 +1,32 @@
 # write-changelog-entry 収束テストの記録
 
-このスキルの作成に関わっていない独立エージェント（Claude Code と Codex。起動できないときは Agent ツールの subagent）に同じ依頼を解かせ、出力の違い（揺れ）を測るための記録である。今回は実行していない。理由は「結論」に書く。
+このスキルの作成に関わっていない独立エージェント（Claude Code と Codex。起動できないときは Agent ツールの subagent）に同じ依頼を解かせ、出力の違い（揺れ）を測るための記録である。今回は収束テストを実行していない。
 
 ## 条件
 
 | 項目 | 値 |
 |---|---|
-| runner | なし（依頼で `measure: skip` が指定され、skill-foundation の STEP-02 の表の skip の行に当たった） |
-| 1 runner あたりの人数 | なし（実行していない） |
-| 課題 | `dev/evals.json`（T1-typical、T2-default、T3-edge、T4-edge、H1-holdout） |
+| runner | なし。skill-foundation の入力 `measure` が `skip` だったため、STEP-02 の表の「skip」の行に従い実行しなかった |
+| 1 runner あたりの人数 | 2（spec の `convergence.agents`。実行していない） |
+| 課題 | `dev/evals.json`（T1-typical、T2-default、T3-edge、H1-holdout） |
 | 合格基準 | status が全員、課題の expect_status と同じ。check が全員通過。スキル自身や hooks の登録を変えたエージェント（失格）がいない。files・structure・names が基準以上。最後のラウンドのレビューの検出率が全見本で 1.0。V1〜V7 の未対処が0件 |
 
 ## ラウンドの一覧
 
 | ラウンド | 課題 | status | files | structure | names | content | check | 失格 | V1〜V7 の未対処 |
 |---|---|---|---|---|---|---|---|---|---|
-| なし | 実行していない | — | — | — | — | — | — | — | — |
+| なし | 実行していない | - | - | - | - | - | - | - | - |
 
 ## レビューの検出率（最後のラウンド）
 
 | 見本 | 決定 | 検出率 | 余計な指摘 | 一致 |
 |---|---|---|---|---|
-| IN-02-r1、OUT-03-r1、OUT-04-r1、OUT-08-r1 | IN-02、OUT-03、OUT-04、OUT-08 | 測っていない | — | — |
+| STEP-01-r1 | STEP-01 | 測っていない | - | - |
+| OUT-04-r1 | OUT-04 | 測っていない | - | - |
 
 ## 結論
 
-収束テストは、利用者が省くと指定した（`measure: skip`）ため実行していない。spec の `convergence.skip_reason` に「利用者が収束テストを省くと指定した」と書いた。決定を機械で守らせる仕組みは、`probe.py` の違反例 14 件、レビューの見本 4 件、標準の確認、hooks の配線 20 件で確かめた。別の AI が同じ出力を作るかと、段 review の決定（IN-02、OUT-03、OUT-04、OUT-08）の検出率は確かめていない。測るときは `convergence.py prepare` から始める。
+収束テストは実行していない。理由は spec の `convergence.skip_reason`（利用者が収束テストを省くと指定した）である。課題の準備（`dev/evals.json` の setup）が一時リポジトリで通ることと、各課題で `changelog_entry.py collect` が期待どおりの終了コード（T1・T2・H1 は0、T3 は5）を返すことだけを確かめた。
+
+- STEP-01-r1: 測っていない。利用者が収束テストを省くと指定したため、レビューの検出率を測らなかった
+- OUT-04-r1: 測っていない。利用者が収束テストを省くと指定したため、レビューの検出率を測らなかった
```

#### `.claude/skills/write-changelog-entry/dev/evals.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.claude/skills/write-changelog-entry/dev/evals.json
+++ subagent-2/.claude/skills/write-changelog-entry/dev/evals.json
@@ -3,62 +3,48 @@
     {
       "id": "T1-typical",
       "kind": "typical",
-      "prompt": "ステージした変更から CHANGELOG の項目を作って",
+      "prompt": "変更履歴（CHANGELOG.md）に足す1節を、ステージ済みの差分から書いてください。",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "printf 'LABEL = \"1 + 2 =\"\\n' > src/config.py",
-        "printf 'from src.config import LABEL\\nfrom src.util import add\\n\\nprint(LABEL, add(1, 2))\\n' > src/app.py",
-        "printf 'def add(a, b):\\n    return a + b\\n\\n\\ndef sub(a, b):\\n    return a - b\\n' > src/util.py",
+        "git apply <<'PATCH'\ndiff --git a/README.md b/README.md\nindex db911e2..2b874df 100644\n--- a/README.md\n+++ b/README.md\n@@ -5,3 +5,6 @@\n ## 使い方\n \n     greet <名前>\n+    greet --shout <名前>\n+\n+名前を省くと、環境変数 `GREET_NAME` の値を使う。\ndiff --git a/greet/cli.py b/greet/cli.py\nindex 5426d32..c17c988 100644\n--- a/greet/cli.py\n+++ b/greet/cli.py\n@@ -1,11 +1,13 @@\n import argparse\n+import os\n \n from greet.core import greet\n \n \n def main(argv=None):\n     parser = argparse.ArgumentParser(prog=\"greet\")\n-    parser.add_argument(\"name\")\n+    parser.add_argument(\"name\", nargs=\"?\", default=os.environ.get(\"GREET_NAME\", \"\"))\n+    parser.add_argument(\"--shout\", action=\"store_true\", help=\"挨拶を大文字で表示する\")\n     args = parser.parse_args(argv)\n-    print(greet(args.name))\n+    print(greet(args.name, shout=args.shout))\n     return 0\ndiff --git a/greet/core.py b/greet/core.py\nindex ebfbf1e..26ca8ae 100644\n--- a/greet/core.py\n+++ b/greet/core.py\n@@ -1,2 +1,5 @@\n-def greet(name):\n-    return \"Hello, \" + name[0].upper() + name[1:] + \"!\"\n+def greet(name, shout=False):\n+    if not name:\n+        name = \"world\"\n+    message = \"Hello, \" + name[0].upper() + name[1:] + \"!\"\n+    return message.upper() if shout else message\ndiff --git a/tests/test_core.py b/tests/test_core.py\nindex 236255a..d475513 100644\n--- a/tests/test_core.py\n+++ b/tests/test_core.py\n@@ -3,3 +3,11 @@ from greet.core import greet\n \n def test_greet():\n     assert greet(\"alice\") == \"Hello, Alice!\"\n+\n+\n+def test_greet_empty():\n+    assert greet(\"\") == \"Hello, World!\"\n+\n+\n+def test_greet_shout():\n+    assert greet(\"alice\", shout=True) == \"HELLO, ALICE!\"\nPATCH",
         "git add -A"
-      ]
+      ],
+      "expect_status": "done"
     },
     {
       "id": "T2-default",
       "kind": "default",
-      "prompt": "今回の変更の変更履歴を書いてほしい",
+      "prompt": "今ステージしてある変更を、CHANGELOG に足す分としてまとめておいて",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "printf 'def add(a, b):\\n    return a + b\\n\\n\\ndef mul(a, b):\\n    return a * b\\n\\n\\ndef div(a, b):\\n    if b == 0:\\n        raise ValueError(\"b must not be 0\")\\n    return a / b\\n' > src/util.py",
-        "git add src/util.py"
-      ]
+        "git apply <<'PATCH'\ndiff --git a/greet/core.py b/greet/core.py\nindex ebfbf1e..30db6fd 100644\n--- a/greet/core.py\n+++ b/greet/core.py\n@@ -1,2 +1,2 @@\n def greet(name):\n-    return \"Hello, \" + name[0].upper() + name[1:] + \"!\"\n+    return \"Hi, \" + name[0].upper() + name[1:] + \".\"\ndiff --git a/tests/test_core.py b/tests/test_core.py\nindex 236255a..d944824 100644\n--- a/tests/test_core.py\n+++ b/tests/test_core.py\n@@ -2,4 +2,4 @@ from greet.core import greet\n \n \n def test_greet():\n-    assert greet(\"alice\") == \"Hello, Alice!\"\n+    assert greet(\"alice\") == \"Hi, Alice.\"\nPATCH",
+        "git add -A"
+      ],
+      "expect_status": "done"
     },
     {
       "id": "T3-edge",
       "kind": "edge",
-      "prompt": "1.2.0 の CHANGELOG の節を書いて。今ステージしてある分です",
+      "prompt": "ステージした変更から CHANGELOG のエントリを書いて",
       "fixture": "dev/fixtures/basic",
       "setup": [
-        "mkdir -p docs tests",
-        "for f in a b c; do printf '# %s\\n' $f > docs/$f.md; done",
-        "printf 'from src.util import add\\n\\n\\ndef test_add():\\n    assert add(1, 2) == 3\\n' > tests/test_util.py",
-        "printf 'LABEL = \"1 + 2 =\"\\n' > src/config.py",
-        "git rm -q README.md",
-        "printf '\\n## [0.0.1] - 2026-09-01\\n\\n### Added\\n\\n- 最初の版を追加（`src/app.py`）\\n' >> CHANGELOG.md",
+        "git apply <<'PATCH'\ndiff --git a/tests/test_core.py b/tests/test_core.py\nindex 236255a..1299a2b 100644\n--- a/tests/test_core.py\n+++ b/tests/test_core.py\n@@ -1,5 +1,8 @@\n+import pytest\n+\n from greet.core import greet\n \n \n-def test_greet():\n-    assert greet(\"alice\") == \"Hello, Alice!\"\n+@pytest.mark.parametrize(\"name, expected\", [(\"alice\", \"Hello, Alice!\"), (\"bob\", \"Hello, Bob!\")])\n+def test_greet(name, expected):\n+    assert greet(name) == expected\nPATCH",
         "git add -A"
-      ]
-    },
-    {
-      "id": "T4-edge",
-      "kind": "edge",
-      "prompt": "変更履歴（CHANGELOG.md）に足す1節を、ステージ済みの差分から書いて",
-      "fixture": "dev/fixtures/basic",
-      "setup": [
-        "printf '# calc\\n\\nA tiny calculator for two numbers.\\n' > README.md"
       ],
       "expect_status": "aborted"
```


## T3-edge

### 実行の状態（期待: done）

- subagent-1: done
- subagent-2: done

### 新しく作った名前（names。先頭 40 件）

- subagent-1: `All`, `Apple`, `CSS`, `CTL-02-builtin-hooks-codex`, `Comments`, `DECORATION`, `DOCTYPE`, `E731`, `EMPTY`, `ESLint`, `Exception`, `FIX`, `FIXME`, `Flavored`, `Git`, `Git-155`, `Google`, `Guide`, `HACK`, `HASH`, `IN-02-a`, `Include`, `JavaScript`, `Kotlin`, `MARKER`, `META_LABELS`, `META_RE`, `NUL`, `PHP`, `Pylint`, `ROWS`, `ROW_RE`, `RULE_RE`, `Rust`, `STEP-01-a`, `Spec`, `Style`, `TABLE_HEAD`, `TABLE_RULE`, `TITLE`
- subagent-2: `Apple`, `COUNT_RE`, `CREATE`, `CTL-02-builtin-hooks-codex`, `Comments`, `DELIMITER`, `DOC_SUFFIXES`, `Documentation`, `ESLint`, `Example`, `Exception`, `FIX`, `FIXME`, `Failure`, `Flavored`, `Git-155`, `Google`, `Guide`, `HACK`, `HEADER`, `IN-02-a`, `INTEGER`, `Issue`, `Last`, `List`, `NOTES`, `NUL`, `OUTPUT`, `OWNER_RE`, `ROW_RE`, `STEP-01-a`, `Spec`, `Style`, `TABLE`, `TITLE`, `TODOS`, `TODO_Comments`, `TODO_RE`, `Tables`, `XXX`

### 一部のエージェントだけが作った・変えたファイル

- `.agents/skills/analyze-todo-comment/assets/examples/todo-comments.md`: subagent-2
- `.agents/skills/analyze-todo-comment/assets/examples/todo-list.md`: subagent-1
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/docs/notes.txt`: subagent-1
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/src/NOTES.md`: subagent-2
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/src/generated/schema.py`: subagent-2
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/src/lib/util.js`: subagent-2
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/src/page.html`: subagent-1
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/src/sql/schema.sql`: subagent-2
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/src/util.js`: subagent-1
- `.agents/skills/analyze-todo-comment/dev/fixtures/basic/web/index.html`: subagent-2

### 中身の違い（抜粋）

#### `.agents/skills/analyze-todo-comment/SKILL.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.agents/skills/analyze-todo-comment/SKILL.md
+++ subagent-2/.agents/skills/analyze-todo-comment/SKILL.md
@@ -1,12 +1,12 @@
 ---
 name: analyze-todo-comment
-description: "リポジトリのソースコードから TODO コメントを集め、ファイル・行・本文の一覧の Markdown を1つ書く。「ソースコードの TODO コメントを一覧の Markdown にして」、「このリポジトリに残っている TODO を洗い出して」、「TODO がどこに残っているか一覧にしてほしい」、「src の下の TODO コメントを表にまとめてください」、「list all TODO comments in this repo」と頼まれたときに使う。TODO コメントに書かれた作業を実装して解消するには使わない（代わりに通常のコード修正の依頼を使う）。課題管理の道具（チケット）の一覧を作るには使わない（代わりに課題管理の道具の検索や出力を使う）。"
+description: "ソースコードのディレクトリを受け取り、その中の TODO コメントを集めて、ファイルと行番号つきの一覧の Markdown を出力する。「ソースコードの TODO コメントを一覧の Markdown にして」、「このリポジトリに残っている TODO を全部洗い出して、一覧にまとめてほしい」、「src 配下の TODO コメントを、ファイルと行番号つきの Markdown にしてください」、「コードのどこに TODO が何件あるか一覧で見たい」、「List all TODO comments in this codebase as Markdown」、「TODO コメントの一覧を Markdown の表で出して」と頼まれたときに使う。TODO コメントに書かれた作業を実装して解消するには使わない（代わりにコードの直接の編集を使う）。TODO コメントを Issue やチケットとして登録するには使わない（代わりにIssue 管理ツール（例：`gh issue create`）を使う）。コードの問題点をレビューして指摘するには使わない（代わりにコードレビュー用のスキルを使う）。"
 ---
 
-# ソースコードの TODO コメントを一覧にする
+# ソースコードの TODO コメントを一覧の Markdown にする
 
 <!-- BEGIN GENERATED:purpose -->
-リポジトリのソースコードから TODO コメントを集め、ファイル・行・本文の一覧の Markdown を1つ書く
+ソースコードのディレクトリを受け取り、その中の TODO コメントを集めて、ファイルと行番号つきの一覧の Markdown を出力する
 <!-- END GENERATED:purpose -->
 
 ## 1. 使う場面
@@ -15,15 +15,17 @@
 次のような依頼で使う。
 
 - 「ソースコードの TODO コメントを一覧の Markdown にして」
-- 「このリポジトリに残っている TODO を洗い出して」
-- 「TODO がどこに残っているか一覧にしてほしい」
-- 「src の下の TODO コメントを表にまとめてください」
-- 「list all TODO comments in this repo」
+- 「このリポジトリに残っている TODO を全部洗い出して、一覧にまとめてほしい」
+- 「src 配下の TODO コメントを、ファイルと行番号つきの Markdown にしてください」
+- 「コードのどこに TODO が何件あるか一覧で見たい」
+- 「List all TODO comments in this codebase as Markdown」
+- 「TODO コメントの一覧を Markdown の表で出して」
 
 次の場合は使わない。
 
-- TODO コメントに書かれた作業を実装して解消する → 代わりに: 通常のコード修正の依頼
-- 課題管理の道具（チケット）の一覧を作る → 代わりに: 課題管理の道具の検索や出力
+- TODO コメントに書かれた作業を実装して解消する → 代わりに: コードの直接の編集
+- TODO コメントを Issue やチケットとして登録する → 代わりに: Issue 管理ツール（例：`gh issue create`）
+- コードの問題点をレビューして指摘する → 代わりに: コードレビュー用のスキル
 
 依頼の内容から自動で選ばれる。明示して呼ぶときは Codex では `$analyze-todo-comment` と書く。
 <!-- END GENERATED:triggers -->
@@ -32,19 +34,19 @@
 
 このファイルがあるディレクトリを `<skill>` と呼ぶ。スクリプトは Python 3.9 以上の標準ライブラリだけで動く。手順は番号の順に行い、飛ばさない。
 
-1. 依頼から「3. 入力」の調べる範囲（`source`）を読み取る。依頼にディレクトリかファイルが書かれていれば、リポジトリのルートからの相対パスにする。書かれていなければ値を作らない（既定値 `.`）。「3. 入力」に start の前に聞く項目は無いので、ユーザーに質問しない。依頼が TODO 以外の印か、リポジトリの中のファイルへの書き込みを求めるときは、IN-01 の表の扱いを手順6で `notes.md` に書く（CTL-03、IN-01）
-2. プロジェクトのルートで `python3 <skill>/scripts/run.py start --set source=<範囲> "<依頼文>"` を実行する。範囲が無いときは `--set` を付けない。終了コード3なら、出力された質問をユーザーに聞き、答えを `--set` で渡してやり直す（CTL-01）
-3. プロジェクトのルートで `python3 <skill>/scripts/collect_todo.py --source <source> --out .skill-runs/analyze-todo-comment/out/todo-list.md` を実行する。`<source>` は start が出力した `source` の値にする。終了コード4・5・2なら、IN-01 の表に従って一覧を書かずに `run.py abort` を実行し、abort が出力した本文をそのまま返答して終える。書かれた一覧は、見本 `assets/examples/todo-list.md` と同じ形になる（IN-01、IN-02、STEP-01、STEP-02、OUT-01、OUT-02、OUT-05）
-4. 一覧のファイルを手で書き換えない。`grep`、`rg`、`git grep` で TODO を探して行を足さない。行を消したり並べ替えたりしない。コメントを訳したり要約したりしない（STEP-01、OUT-03、OUT-04）
-5. `python3 <skill>/scripts/run.py check` を実行する。指摘があれば、ルールIDを「4. 決定表」で引き、start が出力した `source` の値で手順3の `collect_todo.py` を実行し直して一覧を書き直す。検査や契約を変えて通さない（CTL-02、STEP-01）
-6. 決めきれなかったことと、IN-01 の表で `notes.md` に書くとしたことを `.skill-runs/analyze-todo-comment/notes.md` に「- 」の箇条書きで書き、`python3 <skill>/scripts/run.py finish` を実行する。書くことが無ければ notes.md を作らない。終了コード1なら手順5に戻る。終了コード0なら、出力された本文をそのまま返答する（RPT-01、IN-01）
+1. 依頼を「4. 決定表」の IN-01 の表に当てはめ、扱いを決める。依頼から「3. 入力」の `source`（調べるディレクトリ）を読み取る。表で「start の前に聞く」とある項目は無いので、ユーザーに質問せずに進む（CTL-03）
+2. プロジェクトのルートで `python3 <skill>/scripts/run.py start --set source=<調べるディレクトリ> "<依頼文>"` を実行する。依頼にディレクトリが無ければ `--set` を付けない（既定値 `.`）。終了コード3なら、出力された質問をユーザーに聞き、答えを `--set` で渡してやり直す（CTL-01）
+3. プロジェクトのルートで `python3 <skill>/scripts/collect_todo.py collect --source <start が出力した source の値> --out .skill-runs/analyze-todo-comment/out/todo-comments.md` を実行する。一覧は `collect_todo.py` が見本 `assets/examples/todo-comments.md` と同じ形で書く。TODO コメントを `grep` や `rg` で探さず、一覧を手で書いたり書き足したりしない（STEP-01、OUT-01）
+4. 手順3の `collect_todo.py` が終了コード0以外で終わったら、`python3 <skill>/scripts/run.py abort --reason "<collect_todo.py が出力した1行目>"` を実行し、abort が出力した本文をそのまま返答して終える（STEP-02）
+5. `python3 <skill>/scripts/run.py check` を実行する。指摘があれば、ルールIDを「4. 決定表」で引き、手順3のコマンドで一覧を書き直す。検査や契約を変えて通さない（CTL-02）
+6. 手順1で IN-01 の表が notes.md に書くとしたことを `.skill-runs/analyze-todo-comment/notes.md` に「- 」の箇条書きで書き、`python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順5に戻る。終了コード0なら、出力された本文をそのまま返答する（RPT-01）
 
 ## 3. 入力
```

#### `.agents/skills/analyze-todo-comment/assets/contract.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.agents/skills/analyze-todo-comment/assets/contract.json
+++ subagent-2/.agents/skills/analyze-todo-comment/assets/contract.json
@@ -9,20 +9,19 @@
   "inputs": [
     {
       "key": "source",
-      "label": "調べる範囲",
-      "impact": "reversible",
+      "label": "調べるディレクトリ",
       "type": "path",
       "aliases": [
-        "範囲",
         "対象",
+        "調べるデータ",
         "ディレクトリ",
         "フォルダ",
-        "パス",
-        "path",
         "dir",
         "directory",
+        "path",
         "target"
       ],
+      "impact": "reversible",
       "default": "."
     }
   ],
@@ -30,74 +29,69 @@
     {
       "id": "todo-list",
       "label": "TODO コメントの一覧",
-      "path": "{run}/out/todo-list.md",
+      "path": "{run}/out/todo-comments.md",
       "rule": "OUT-01",
       "count": {
         "min": 1,
         "max": 1
       },
+      "name_pattern": "^todo-comments\\.md$",
+      "format": [
+        {
+          "type": "trailing_space",
+          "rule": "OUT-02"
+        },
+        {
+          "type": "final_newline",
+          "rule": "OUT-02"
+        }
+      ],
       "checks": [
         {
-          "rule": "OUT-02",
           "type": "headings",
           "equals": [
             "TODO コメントの一覧"
           ],
-          "message": "見出しは「# TODO コメントの一覧」の1つだけ"
+          "rule": "OUT-02",
+          "message": "見出しは1行目の `# TODO コメントの一覧` だけにする"
         },
```

#### `.agents/skills/analyze-todo-comment/assets/seal.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.agents/skills/analyze-todo-comment/assets/seal.json
+++ subagent-2/.agents/skills/analyze-todo-comment/assets/seal.json
@@ -1,14 +1,14 @@
 {
   "runtime": "1.0.0",
   "files": {
-    "SKILL.md": "fc9cf36fcd01093e59df17e54675e162dac4b6e27252892da50bb97226638cbd",
-    "assets/contract.json": "76d7ef239652904c314c4366331bb5e4348aa15f5d66ef4c02c4dc3c8eb24d27",
-    "assets/examples/todo-list.md": "0c8bb9b7e556dac9f57674161f378db849987c783823e1699c7a94f4f74f7867",
-    "references/decisions.md": "62d9b40172016a72c1ff5dc5fd1e5ae7ac8bee7aea97909cab9db8b1197176a1",
+    "SKILL.md": "ba87cf3623c8ea4a2bd02499cb28ecf970848237beca57f424c545e1f1a91e35",
+    "assets/contract.json": "4bf24fa30bdbd49cdff4f19819856aed16e83472791814f6982c133c0856a106",
+    "assets/examples/todo-comments.md": "2ac9eae060318c68b041b8abbe4b6ba84c99d75305b1e2a92c3ef79d8802720b",
+    "references/decisions.md": "4710c91d57fe004958e3c1b05fb93916519646f05317c0e6f55a6858292d0200",
     "scripts/run.py": "fcced04ce88880bbe860dadc1d25481c464f13d733de4d4c7d9c5ccbde096b76",
     "scripts/_skillrt.py": "b76eceeda4fdcad10a4246a66a7d137d2400cec49cc62d95ec89fd463b784304",
     "scripts/hook.py": "b0ccd614d242fcbbd2499da75d759b33b4cb8f7c7357563954570f15c3a7ef55",
     "scripts/install.py": "286effaa9680fd4f8a03816b37252e36b62172301ef9d64c8debd4646d91ea19",
-    "scripts/collect_todo.py": "a22aab880b689feb6b9156163ff08e812b5391aac44bc1efed26b6b75f8beffe"
+    "scripts/collect_todo.py": "7232bc85d76ba250b38f8cb53811e99a0e49c9bc2fa6faef0f0f6138a62ead78"
   }
 }
```

#### `.agents/skills/analyze-todo-comment/dev/convergence-report.md`（subagent-1 と subagent-2）

```diff
--- subagent-1/.agents/skills/analyze-todo-comment/dev/convergence-report.md
+++ subagent-2/.agents/skills/analyze-todo-comment/dev/convergence-report.md
@@ -1,28 +1,30 @@
 # analyze-todo-comment 収束テストの記録
 
 このスキルの作成に関わっていない独立エージェント（Claude Code と Codex。起動できないときは Agent ツールの subagent）に同じ依頼を解かせ、出力の違い（揺れ）を測った記録である。生データは `dev/results/convergence/round-<R>/` にある。
+
+このスキルでは収束テストを実行していない。作成の依頼に「収束テスト: しない」とあり、skill-foundation の入力 `measure` が `skip` になったためである（skill-foundation の STEP-02）。省いた理由は `dev/spec.json` の `convergence.skip_reason` にある。
 
 ## 条件
 
 | 項目 | 値 |
 |---|---|
-| runner | なし。skill-foundation の入力 `measure` が `skip`（依頼の「収束テスト: しない」）なので、STEP-02 の表の `skip` の行に従い実行していない |
-| 1 runner あたりの人数 | 0 |
-| 課題 | `dev/evals.json`（T1-typical、T2-default、T3-edge、H1-holdout。実行していない） |
+| runner | なし。`measure` が `skip` のため、STEP-03 の表で runner を選んでいない |
+| 1 runner あたりの人数 | なし |
+| 課題 | `dev/evals.json`（作ったが、実行していない） |
 | 合格基準 | status が全員、課題の expect_status と同じ。check が全員通過。スキル自身や hooks の登録を変えたエージェント（失格）がいない。files・structure・names が基準以上。最後のラウンドのレビューの検出率が全見本で 1.0。V1〜V7 の未対処が0件 |
 
 ## ラウンドの一覧
 
 | ラウンド | 課題 | status | files | structure | names | content | check | 失格 | V1〜V7 の未対処 |
 |---|---|---|---|---|---|---|---|---|---|
-| なし | 実行していない | - | - | - | - | - | - | - | - |
+| なし | | | | | | | | | |
 
 ## レビューの検出率（最後のラウンド）
 
 | 見本 | 決定 | 検出率 | 余計な指摘 | 一致 |
 |---|---|---|---|---|
-| なし（`dev/probes.json` の reviews が無い） | - | - | - | - |
+| なし（`dev/probes.json` に reviews が無い） | | | | |
 
 ## 結論
 
-収束テストは実行していない。spec の `convergence.skip_reason` は「利用者が収束テストを省くと指定した」である。独立エージェントが同じ依頼から同じ一覧を作るかは測っていない。出力の決定（IN-02、STEP-01、STEP-02、OUT-01〜OUT-05）は `collect_todo.py` が一覧を書き、契約の検査が集め直した結果と比べるので、違反は `dev/probes.json` の違反例で止まることを確かめた。
+収束テストを省いたため、合格基準を満たしたかは確かめていない。決定の守らせ方は、`probe.py` の違反例 9 件と標準の確認がすべて成功したことで確かめた（`dev/results/probe-results.json`）。
```

#### `.agents/skills/analyze-todo-comment/dev/evals.json`（subagent-1 と subagent-2）

```diff
--- subagent-1/.agents/skills/analyze-todo-comment/dev/evals.json
+++ subagent-2/.agents/skills/analyze-todo-comment/dev/evals.json
@@ -1,42 +1,8 @@
 {
   "tasks": [
-    {
-      "id": "T1-typical",
-      "kind": "typical",
-      "prompt": "このリポジトリに残っている TODO コメントを洗い出して、Markdown の一覧にして",
-      "fixture": "dev/fixtures/basic",
-      "setup": [
-        "mkdir -p build && printf '// TODO: generated\\n' > build/gen.js"
-      ],
-      "expect_status": "done"
-    },
-    {
-      "id": "T2-default",
-      "kind": "default",
-      "prompt": "TODO コメントを一覧にして",
-      "fixture": "dev/fixtures/basic",
-      "setup": [],
-      "expect_status": "done"
-    },
-    {
-      "id": "T3-edge",
-      "kind": "edge",
-      "prompt": "docs の下の TODO コメントを一覧の Markdown にまとめてください",
-      "fixture": "dev/fixtures/basic",
-      "setup": [],
-      "expect_status": "done"
-    },
-    {
-      "id": "H1-holdout",
-      "kind": "holdout",
-      "prompt": "list all TODO comments under tools/ as a Markdown list",
-      "fixture": "dev/fixtures/basic",
-      "setup": [
-        "mkdir -p tools",
-        "printf '#!/bin/sh\\n# TODO: 失敗したら止める\\necho \"TODO: not a comment\"\\n' > tools/deploy.sh",
-        "printf -- '-- TODO: 索引を足す\\nSELECT 1; /* TODO: 件数を数える */\\n' > tools/report.sql"
-      ],
-      "expect_status": "done"
-    }
+    {"id": "T1-typical", "kind": "typical", "prompt": "src の TODO コメントを一覧の Markdown にして", "fixture": "dev/fixtures/basic", "setup": [], "expect_status": "done"},
+    {"id": "T2-default", "kind": "default", "prompt": "このリポジトリに残っている TODO コメントを全部洗い出して、一覧にまとめてほしい", "fixture": "dev/fixtures/basic", "setup": [], "expect_status": "done"},
+    {"id": "T3-edge", "kind": "edge", "prompt": "tools ディレクトリの TODO コメントを Markdown の一覧にしてください", "fixture": "dev/fixtures/basic", "setup": ["mkdir -p tools", "printf '#!/bin/sh\\n# 起動するだけのスクリプト\\necho hello\\n' > tools/run.sh"], "expect_status": "done"},
+    {"id": "H1-holdout", "kind": "holdout", "prompt": "web 配下の TODO と FIXME を、ファイルと行番号つきの Markdown にして", "fixture": "dev/fixtures/basic", "setup": [], "expect_status": "done"}
   ]
 }
```

#### `.agents/skills/analyze-todo-comment/dev/fixtures/basic/.gitignore`（subagent-1 と subagent-2）

```diff
--- subagent-1/.agents/skills/analyze-todo-comment/dev/fixtures/basic/.gitignore
+++ subagent-2/.agents/skills/analyze-todo-comment/dev/fixtures/basic/.gitignore
@@ -1 +1 @@
-build/
+src/generated/
```
