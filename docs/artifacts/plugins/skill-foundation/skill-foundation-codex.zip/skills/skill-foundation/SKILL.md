---
name: skill-foundation
description: "作りたいスキルの依頼から、ルール・出力の契約・hooks とスクリプトによる制御・違反例・収束テストを備え、Claude Code と Codex のどちらでも同じ結果になるスキルを作る。「スキルを作って」、「コミットメッセージを書くスキルを作って」、「誰が使っても同じ結果になるスキルにしたい」、「Codex でも Claude Code でも使えるスキルを作成して」、「hooks とスクリプトで出力を縛るスキルを作って」、「この作業手順を SKILL.md にまとめてスキル化して」、「この既存のスキルを、誰が使っても同じ結果になるように作り直して」、「Create a skill that gives the same result on any AI」と頼まれたときに使う。リポジトリ全体の規約・lint・ディレクトリ構造を作る依頼には使わない（代わりにpattern-foundationを使う）。skill-foundation で作ったスキルのルールや契約の小さな修正には使わない（代わりにそのスキルの dev/spec.json の修正と render_skill.pyを使う）。"
---

# skill-foundation plugin

このファイルは plugin 用の入口である。まず、このファイルからの相対パス `../../runtime/skill-foundation/SKILL.md` を読み、そこに書かれた手順と参照資料に従う。正本全体は `runtime/skill-foundation/` に含まれている。正本でいう `<skill>` と `<skill-foundation>` は、そのディレクトリを指す。

plugin での実行に限り、次の接続方法を使う。ルール、契約、検査、出力は正本に従う。

- skill-foundation 自身の `install.py` は実行しない。plugin が skill-foundation の hooks を提供する。作成した別のスキルの `install.py` は正本の手順どおり実行する。
- skill-foundation の `scripts/convergence.py` を呼ぶときは、代わりに plugin ルートの `scripts/convergence.py` を使う。引数は正本と同じにする。この接続処理は、runner `subagent` の準備時にプロジェクトへ専用エージェントを書き出さず、同梱のエージェントを案内する。ほかのスクリプトは正本のものを使う。
- Claude Code の Agent ツールでは、専用のエージェント型を `skill-foundation:skill-foundation-tester` に読み替える。プロンプトの前後に文を足さず、新しいエージェントに渡す。専用型が利用できなければ、通常のエージェントで代用せず、正本の STEP-03 に従って起動できる CLI を使う。Codex のサブエージェントでは専用型の fence は働かないという正本の限界も維持する。
- plugin のコード、設定、`runtime/` は編集しない。スキルの作成先と実行記録は、利用者のプロジェクト内にする。
