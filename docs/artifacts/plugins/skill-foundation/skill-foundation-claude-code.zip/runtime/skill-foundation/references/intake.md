# 受付（フェーズ0）

フェーズ0では、作るスキルの「受付の項目」を決めて `dev/spec.json` に書く。受付の項目は `name`、`kind`、`mode`、`language`、`targets`、`title`、`purpose`、`triggers` の8つである。ここで決めた値から、置き場所と description が機械的に決まる。手順3で Eval を作ったなら、`purpose` は `dev/eval/eval.json` の確定した価値から、`triggers.use_when` は利用場面から書く（[eval.md](eval.md)）。手順4で決めた hooks の方針（`dev/hooks-plan.json`）は、受付の項目ではなく、受付の後に `init_skill.py` が spec の `control` に写す（STEP-08）。skill-foundation 自身は、スキルを作る側なので `kind` を持たず、名前も `<動詞>-<目的語>` の形にしていない（`init_skill.py` と `skill_lint.py` が skill-foundation 自身を、この2つの検査から外す）。そのため、ここでばらつくと後のすべてがばらつく。

この章は次の順に読む。1章でユーザーに何を聞くかを決め、2章から5章で各項目の値を決め、6章で対象外の依頼を断る。

## 1. 聞くことと、聞かずに決めること

受付の質問は `run.py start` の前に1回だけまとめて行う（CTL-03）。次の表の「依頼に無いとき」に従う。表に無い項目は聞かない。start の後に聞くのは、OUT-06（既存のスキルへの後付け）、STEP-06（Eval の材料と価値の確定）、STEP-08（hooks の方針）、STEP-02（収束テストを実行するか）、STEP-04（ラウンドを足すか）の場合分けが `run.py wait --question` を指示するときだけである。

| 項目 | 依頼に無いとき |
|---|---|
| 目的（何を受け取り、何を出力するか） | 聞く。「何を受け取って、何を出力するスキルですか」と1文で尋ねる |
| 名前（`name`） | 聞かない。2章の規則で決める |
| 種類（`kind`） | 聞かない。2章の表で選んだ動詞にする |
| 作り方（`mode`） | 受付では聞かない。`new` にする。同じ名前の既存のスキルがあるときは、SKILL.md の OUT-06 の表に従い、start の後に wait してから後付けにするかを聞く |
| 対象の製品（`targets`） | 聞かない。依頼に指定（「Codex だけで使う」など）があるときだけ `--set` で渡す。無ければ渡さない（設定、無ければ既定値 `claude,codex`） |
| 言語（`language`） | 聞かない。3章で決める |
| 収束テストの実行（`measure`） | 聞かない。依頼に指定があるときだけ `--set` で渡す。無ければ渡さない（設定、無ければ既定値 `ask`。実行の直前に回数を示して確かめる） |
| Eval の作成（`eval`） | 聞かない。依頼に指定があるときだけ `--set` で渡す。無ければ渡さない（設定、無ければ既定値 `make`。手順3で材料を聞いて作る） |
| hooks の方針（`hooks`） | 受付では聞かない。依頼に指定（「hooks は使わない」など）があるときだけ `--set` で渡す。無ければ渡さない（設定、無ければ既定値 `all`）。手順4で、指定が無ければカタログで聞き、聞けないときはこの値で決める（STEP-08） |
| 自動で起動するか（`triggers.implicit`） | 聞かない。5章の表で決める |
| 上のどれでもない | 聞かない。既定値を使い、報告の「補足」に書く |

表の「設定」は、skill-foundation の `settings/user-setting.yaml`（ユーザーの設定）と `settings/skill-setting.yaml`（スキルの設定）の `inputs` で、`run.py start` がこの順に null でない最初の値を使う。ユーザーの設定は各自の手元にだけ置くファイルで、無ければ飛ばす。作るときは、利用者が `scripts/setup.py` で選ぶか、`assets/templates/user-setting.example.yaml` を写す。依頼の指定（`--set` と依頼文の「キー: 値」の行）は設定より強い。どこから決まったかは、start の出力と報告の「既定値で決めた値」に出る。

ユーザーが値を指定したときは、その値を使う。ただし `name` が2章の形に合わないときは、2章の規則で直した名前を使い、報告の「補足」に元の指定と直した理由を書く。

## 2. 名前の付け方

名前は `<動詞>-<目的語>` の kebab-case（英小文字・数字・ハイフン）で、64 文字以内にする。動詞は次の表から1つ選ぶ。表の上から順に当てはめ、最初に当たった行を使う。出力の形（Markdown、一覧、表）では選ばず、出力の中身を誰がどう作るかで選ぶ。

| スキルの主な出力 | 動詞 |
|---|---|
| 人が読む文章で、AI が文を組み立てるもの（メッセージ、説明、文書） | `write` |
| 指摘の一覧（レビュー結果） | `review` |
| 既存のコードや文書の修正 | `fix` |
| 入力の全体を、要素を落とさずに別の形式へ写したもの（入力の要素と出力の要素が1対1） | `convert` |
| 入力を調べて、条件に合う部分を集めたもの、数えたもの、要約したもの | `analyze` |
| 定期的な報告書 | `report` |
| 環境や設定ファイル | `setup` |
| 新しいコードやファイル（文章以外） | `generate` |
| 上のどれでもない | `run` |

例：ソースコードの TODO コメントの一覧は `analyze`（ソースの一部を集める）、Markdown の文書を HTML にするのは `convert`（全体を写す）、変更履歴の1節は `write`（AI が文を書く）である。

選んだ動詞を spec の `kind`（スキルの種類）に書く。種類ごとに、軸の読み替え、追加の軸、重点軸、検査の候補、入力の候補（作ったスキルが利用者に聞くべき事項）、調べる先、課題の例が [skill-profiles.md](skill-profiles.md) に決めてある。フェーズ2・3・4・6で、その種類の節を読む。入力の候補は、spec の `inputs` に同じ key で入れるか、`excluded_inputs` に key と理由を書く（`skill_lint.py` が確かめる）。調べる先は、フェーズ2で `dev/research.md` に調べた結果を書くときの当たり先である。

目的語は、出力の対象を表す英語の名詞にする。複数語ならハイフンでつなぐ。冠詞と複数形の `s` は付けない。

- 良い例：`write-commit-message`、`review-pull-request`、`generate-api-client`
- 悪い例：`commit-helper`（動詞が無い）、`writeCommitMessage`（kebab-case でない）、`write-the-commit-messages`（冠詞と複数形）

## 3. 言語

`language` は、スキルの SKILL.md と報告を書く言語である。依頼に言語の指定（「英語で書いて」「in English」など）があれば、その値を `--set language=<言語>` で渡す。無ければ、依頼文の言語を次の表で決めて `--guess language=<言語>` で渡す。`--guess` はユーザーの設定とスキルの設定より弱いので、設定に `language` があれば設定の値になる（skill-foundation の設定は null で、依頼文の言語に従う）。

| 依頼文の言語 | `language` |
|---|---|
| 日本語 | `ja` |
| 上のどれでもない | `en` |

## 4. 対象の製品と置き場所

`targets` に挙げた製品が、スキルを見つけられる場所に置く。本体の置き場（`base`）は次の表で決める。

| `targets` | 本体（`base`） | もう一方の置き場 |
|---|---|---|
| `claude,codex` | `.claude/skills` | `.agents/skills/<name>` を本体への相対シンボリックリンクにする（`install.py` が作る） |
| `claude` | `.claude/skills` | なし |
| `codex` | `.agents/skills` | なし |
| 上のどれでもない | `.claude/skills` | なし |

置き場は `targets` からこの表で決まるので、依頼に置き場の指定が無ければ `base` を渡さない。start が、決まった `targets` から表の置き場を補う（契約の入力の `default_by`）。置き場は、作業しているプロジェクトのルートからの相対パスである。ユーザーのホーム（`~/.claude/skills`、`~/.agents/skills`）には置かない。

`skill_lint.py --final --project` は、本体がこの表の置き場にあるかと、もう一方の置き場が本体へのリンクか（`install.py --check`）を確かめる。本体をほかの場所（プロジェクトの直下など）に置いたり、置き場に複製を置いたりすると、完了しない。依頼が表と違う置き場を求めるときは、先にユーザーに表の置き場でよいかを聞く。

## 5. 起動の条件（`triggers`）

`triggers` は description の元になる。

- `use_when`：このスキルを使う依頼を、ユーザーが実際に書く言い方で5つ以上書く。1つ目には受けた依頼文そのもの（固有名詞を除いたもの）を書く。言い方の違い（丁寧さ、語順、英語交じり）を混ぜる
- `not_for`：このスキルと紛らわしいが使わない依頼と、代わりに使うものを、`{"when": ..., "instead": ...}` の形で1つ以上書く
- `implicit`：次の表で決める

| スキルの出力 | `implicit` |
|---|---|
| プロジェクトの外に影響する（送信、公開、デプロイ、削除、課金） | `false`（明示したときだけ起動する） |
| 上のどれでもない | `true` |

`implicit: false` のとき、Claude Code 向けに frontmatter の `disable-model-invocation: true` が生成される。Codex では自動の起動を止めない。

## 6. 対象外の依頼

次の依頼は skill-foundation の対象外である。この判定は `run.py start` の前に行う。対象外なら start を実行せず、ファイルも作らずに、代わりに使うものを返答する（IN-01）。

| 依頼 | 代わりに使うもの |
|---|---|
| リポジトリ全体の規約、lint、ディレクトリ構造を作る | pattern-foundation |
| 1回限りの作業をしてほしい（繰り返し使う手順ではない） | その作業を直接行う |
| skill-foundation で作ったスキルのルールや契約の小さな修正 | そのスキルの `dev/spec.json` を直し、`render_skill.py` と `skill_lint.py` を実行する |
| skill-foundation で作っていない既存のスキルを、誰が使っても同じ結果になるようにしたい | 対象である。spec の `mode` を `retrofit` にして SKILL.md の手順2に進む（OUT-06） |
| 上のどれでもない | 対象である。SKILL.md の手順2に進む |
