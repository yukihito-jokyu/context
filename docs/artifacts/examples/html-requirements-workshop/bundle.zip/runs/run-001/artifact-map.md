# 成果物対応表

| 成果物 | 入力 | 生成責務 |
|---|---|---|
| `mockups/001-artifact-gallery.html` | project、mock_html、review_points、fixed_annotations、screen_details | 2つの確認モードをテンプレートへ決定論的に配置 |
| `requirements.md` | requirements | 固定見出しでMarkdown化 |
| `mock-index.html` | snapshot、project | `001-artifact-gallery.html`へのリンクを生成 |
| `validation.json` | 全生成物 | 必須構造とファイル存在を検証 |
| `manifest.json` | 入力、テンプレート、全生成物 | SHA-256を記録 |
