# 共通 Skill

| Skill | 概要 |
|---|---|
| [artifact-links](documentation/artifact-links/SKILL.md) | 掲載する成果物の原本、画面画像、取得方法を確認する。 |
