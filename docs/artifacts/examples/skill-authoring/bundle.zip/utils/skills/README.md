# 共通スキル

SKILL.mdを正本とし、このREADMEは要約カタログとして扱う。

## 証跡・説明

| スキル | 用途 |
| --- | --- |
| [artifact-links](documentation/artifact-links/SKILL.md) | 実成果物の原本・画像・取得リンクの対応を確認する。 |
