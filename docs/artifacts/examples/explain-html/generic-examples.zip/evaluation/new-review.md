# 新版4成果物の独立レビュー

新版4成果物は本文の主な規則と具体例を説明できています。図の矢印と本文の具体値も概ね一致しています。一方、図の型を選んだ後のノード分類と凡例、重要な状態変更の結果、具体条件を図へ落とす工程が不足しています。図の種類数、ノード数、計画ファイルの存在だけでは品質を判定していません。

## 評価範囲

各題材のprompt.txt、with_skill/outputs/index.html、page-model、全図モデル、diagram-plan、coverageを読んだうえで、parent-static-previewsの22図をview_imageで視認しました。APIはraster-compatible.png、他3題材は親のCSS変数解決済みPNGを使用しています。派生画像は元SVGの表示内容を確認する補助であり、ブラウザ標準PNGと同一とは認定しません。

このレビュアーは新版4成果物を制作していません。旧版APIはレビュアー自身が制作したため、比較の自己評価から除外しました。他旧版も今回の採点根拠にはしていません。スキルと制作済みHTML・モデル・図は変更していません。各新版outputs/grading.jsonと本レビューだけを追加しました。

実ブラウザは起動も操作もしていません。実表示の可読性、狭幅での見え方、ナビ・履歴・深いリンク・再生・印刷の操作は未検証です。期待値4の合格は「HTMLが全viewBoxを幅100%で配置し、読み取りサイズ切替や初期固定最小幅を付けない」という静的構造の判定です。見た目や操作の合格へ拡張しません。

## 共通期待値の結果

| 題材 | 1 一致 | 2 必要な関係 | 3 根拠のない型なし | 4 初期全体表示 | 5 欠落なし | 合格数 |
| --- | --- | --- | --- | --- | --- | --- |
| 非同期API | ○ | ○ | × | ○（静的） | ○（静的） | 4 / 5 |
| 備品貸出 | ○ | × | × | ○（静的） | ○（静的） | 3 / 5 |
| 水循環 | ○ | × | ○ | ○（静的） | ○（静的） | 4 / 5 |
| 売上集計 | ○ | ○ | × | ○（静的） | ○（静的） | 4 / 5 |

各題材のgrading.jsonに5項目それぞれのtext、passed、evidenceと、summaryのpassed、failed、total、pass_rateを保存しました。この合格率は5条件の充足率であり、成果物全体の完成度を精密な数値で表すものではありません。

## 非同期API

要求と応答をsequenceで分けた点が、初めて読む開発者の理解を支えています。POSTに202とjob_17が返り、後のGETにcompletedとresultUrlが返るため、202と完了が別の出来事であることを図から追えます。同じrequestKeyの通信例、jobIdの照会、queued/runningと成功/失敗の分岐、503の再試行と停止も本文に対応します。

[example.json 52行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/with_skill/outputs/diagrams/example.json:52)

> "label": "② 202 + job_17"

[retry.json 100行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/with_skill/outputs/diagrams/retry.json:100)

> "label": "再送回数 < 2"

再試行ループは回数を増やす動作を図中に明示しないため、本文の「初回に追加する2回」と通信ログを読んで回数を補う必要があります。回数の初期値と加算を示すと、ループの終了条件を図だけでも説明できます。これは今回、本文と図に矛盾があるとは判定していません。

問題は、保存概念として描くジョブ記録へdatabase型を付け、標準凡例にも「データベース」を出したことです。原文はジョブ状態・結果の保存だけを規定しています。本文は内部実装を決めないとするため、図の分類が本文より具体的な構成を示しています。DB製品やテーブル構造を捏造したという判定ではなく、未指定の保存方式を型と凡例で断定した点の指摘です。

[overview.json 45行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/with_skill/outputs/diagrams/overview.json:45)

> "type": "database"

[page-model.json 54行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/with_skill/outputs/page-model.json:54)

> ワーカーとジョブ記録の線は保存操作の概念表現です。DB製品やキューの内部実装は決めていません。

## 備品貸出

CAM-03、10月11日、7日後の10月18日が本文と成功例図で一致しています。担当者の三条件をANDとして扱い、不成立なら貸出せず終了する分岐は正しいです。期限内の返却と延滞後の返却も、同じ例で両方起こるとは説明していません。

ただし、状態図は「新規貸出を止める」を描きながら、返却後に解除される結果を描きません。返却で閉じる貸出記録、在庫復帰、新規貸出制限の解除は別の状態ですが、ページ自体が三つを説明する以上、解除という重要な結果を図の注記または対応する関係へ残す必要があります。本文に解除の説明はあるため、内容の欠落全体ではなく「必要な状態変化を図から説明できない」という期待値2の不合格です。

[states.model.json 50行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/with_skill/outputs/states.model.json:50)

> "sublabel": "新規貸出を止める"

[states.model.json 59行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/with_skill/outputs/states.model.json:59)

> "sublabel": "CAM-03は在庫へ戻る"

[page-model.json 46行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/with_skill/outputs/page-model.json:46)

> 担当者が延滞記録を閉じると、その延滞による新規貸出制限は解除されます。

利用者・担当者・会員証・記録にexternal型を使ったため、図には「外部システム」の凡例が残ります。窓口の人や書類を外部システムと呼ぶ根拠はありません。比較相手やプログラムは追加していませんが、型の表記が題材に適合していません。

[overview.model.json 28行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/with_skill/outputs/overview.model.json:28)

> "type": "external"

成功例に対象ノードが一つもない「貸出しない場合」のレーンが残っています。読者は空の領域にも何かあるかを探すため、全体図の理解に不要な視線移動が生じます。状態図は1300×780のviewBoxに3状態を上側へ配置し、下側の広い空白を残しています。標準SVGの切抜きで対処せず、元モデルのレーンと配置・viewBoxを必要範囲に合わせるべきです。

[example.model.json 18行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/with_skill/outputs/example.model.json:18)

> "label": "貸出しない場合"

[states.model.json 10行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/with_skill/outputs/states.model.json:10)

> "viewBox": [
>   1300,
>   780
> ]

## 水循環

海・大気・地表・地下水・河川の貯留と移動をつなぎ、森林へ降る雨の例で地表と地下の経路を分けています。土壌・地層の仮定、未測定の割合・時間、面積100m²×雨量10mmの体積換算も、実測結果として実在化していません。指定URLを取得できず現行USGSページと関連資料へ移った経緯を本文に明記しています。指定URLと現行ページの完全一致は未確認です。

相変化のページは「水の形と戻り道」を問うのに、蒸発、蒸散、凝結、降雪、融解の5本だけを描きます。凍結、昇華、雨で液体の水へ戻る経路は本文にあるものの図にありません。特に昇華は「液体を経ず気体になる」という対比を理解する関係なので、本文だけで補うと図の形の変化を追う目的が弱まります。図が全部の細かな経路を持つ必要はありませんが、このページの問いに答える相変化は図へ残すべきです。

[details.json 76行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/with_skill/outputs/diagrams/details.json:76)

> "label": "水が凝結する"

[details.json 88行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/with_skill/outputs/diagrams/details.json:88)

> "label": "雪・氷が融ける"

[page-model.json 30行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/with_skill/outputs/page-model.json:30)

> 昇華は図の「雪・氷 → 液体 → 水蒸気」と別の経路であり、雪が必ず融けてから大気へ戻るわけではありません。

凝結の行き先を「雲の水滴・氷」と一括する表記も、凝結で液滴を生む関係と氷を生む関係を読み分けにくくしています。ただし雲の液滴を凝結で生む関係は成立するため、今回この短縮だけで根拠のない事実と断定していません。

条件の図は、雨量・土壌・斜面から「条件が浸透を変える」「条件が流出を変える」としか示しません。本文にある「強い雨が受入速度を上回る」「すでに飽和している」などの条件と、その結果の経路を図内で対応できません。条件と結果の図としては抽象度が高すぎます。

[conditions.json 64行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/with_skill/outputs/diagrams/conditions.json:64)

> "label": "条件が浸透を変える"

全5図は940×720の画像で、主要3列を左側約600pxまでに配置し、右側に大きな未使用領域を残しています。この余白は図を幅100%にしたときに内容と文字を一緒に縮める要因です。読み取り切替は足していませんが、元モデルの配置を改める余地があります。図の凡例は「データフロー」であり、水の移動・相変化・条件の影響という関係の違いを読者へ十分案内しません。

## 売上集計

5入力行から4正常・1不正、3採用・1重複へ分かれ、2000と500を保存する値が本文・図で一致します。取込処理、集計処理、レポートの担当が明確です。不正行と正常重複行は別の保存先で止まり、集計へ戻る矢印がありません。検証を先に行うため「最初の正常行」の意味も本文と図から追えます。

[example.model.json 44行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/with_skill/outputs/example.model.json:44)

> "sublabel": "4行正常・1行不正"

[example.model.json 52行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/with_skill/outputs/example.model.json:52)

> "sublabel": "3行採用・1行重複"

[example.model.json 68行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/with_skill/outputs/example.model.json:68)

> "sublabel": "2000 / 500"

この題材は全図workflowですが、入力と変換、条件と例外、保存と読取を表せています。dataflowを使わなかったことや図の種類数を理由に減点していません。ただし図の合計には日付がなく、2000が10月11日、500が10月12日であることは近くの本文から補う必要があります。具体出力図として日付と値を一緒に示すと対応が強まります。

問題は入力CSV、daily_sales、隔離ファイル、重複記録をexternal型にして「外部システム」の凡例を出した点です。本文は保存先のファイル/DB方式を未指定と明示していますが、図はデータ・保存概念をシステムという別の概念へ分類します。DBの列やキーを捏造したという評価ではありません。

[example.model.json 66行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/with_skill/outputs/example.model.json:66)

> "type": "external"

[page-model.json 30行目](/Users/yukihito/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/with_skill/outputs/page-model.json:30)

> ファイルかDBか、テーブルの列やキー、保存先パスを定めていません。

## 計画契約とスキルの照合

現正本は型の使い分けを具体化し、要求/応答、条件/停止、対象の状態、情報/物質の変換を分けています。スナップショットは「誰がいつ何をするか」「何がどう変化するか」に複数型をまとめていました。新版は図の問いに応じた計画を保存した点で現正本へ対応しますが、型の名前を選ぶだけでは条件や結果の欠落を防げていません。

[現正本 explanation-patterns.md 21行目](/Users/yukihito/Documents/github_projects/context/utils/skills/discovery/explain-html/references/explanation-patterns.md:21)

> ノードには図の意味に合う種類を指定し、色やfrontend/securityなどの型を配置順で割り当てない。

[現正本 explanation-patterns.md 39行目](/Users/yukihito/Documents/github_projects/context/utils/skills/discovery/explain-html/references/explanation-patterns.md:39)

> モデル検証後は計画と実際の図を照合する。理由のない型の変更、必要な関係を削った簡素化、主体・値・時点の不一致があれば修正する。

22計画は所定フィールドを持ち、model_pathとtarget_idsはすべて存在しました。全項目がrole=overview、parent_diagram_id=nullでも、各関心ページの全体図を登録しているので、detailがゼロという数だけで不合格にはしません。

計画契約の意味上の不足は別に残ります。備品貸出の状態計画は「未返却、延滞、返却で何が変わるか」を問いながら、解除結果をrelationsに残していません。水循環は図ごとに同じselection_reasonを使い、条件図の制御・因果と、水が移動する図の物質フローを区別する制作要件が弱いです。各図のscopeは題材全体の範囲を繰り返すことが多く、描く開始/終了と図に含める仮定を十分個別化していません。形式的な計画存在は満たしますが、問いと答え・条件・結果・型の意味をレビューした契約としては部分未充足です。

## 防ぐための汎用指示案

1. **図の語彙も原文と照合する。** 型、ノード記号、凡例、レーン名を本文と同じ主張として扱う。「人物」「書類」「保存概念」「処理」「状態」などの意味を計画に書き、対応スキーマの意味と照合する。原文が保存方式を指定しないならdatabaseと断定しない。スキーマの既定分類が題材を表せない場合は、意味を保てる別型・契約上許される中立表現を検討し、使える代替がなければ制約を明示する。標準画像の凡例を独自編集して隠す対処はしない。
2. **問いへの答えを一本ずつ図で説明する。** 制作者は全矢印の始点、終点、受け渡す値/変化、成立条件、結果を短い文で読み上げ、本文の主要規則へ逆照合する。停止だけでなく解除、受付だけでなく応答、変換だけでなく入力と出力を確認する。必要な矢印がない場合は本文の補足だけで合格にしない。
3. **条件図には条件の中身を残す。** 「判定」「条件が変える」だけではなく、対象題材で何が成立したときどこへ進むかを示す。反復には初期値と更新、相変化には前後の形、集計にはグループキーと値を含める。すべてを一枚へ詰めず、読者の問いごとに分割する。
4. **初期全体表示を元モデルで整える。** 空レーン、実際には使わない領域、過剰なviewBoxの余白をモデル段階で見直す。標準SVGを切り抜かず、拡大切替や固定幅で問題を先送りしない。ブラウザが使えない場合は、派生静的画像の可視領域と余白を確認し、実表示の可読性を未検証と記録する。
5. **計画と本文の対応を具体化する。** scopeには図の開始/終了と仮定、relationsには条件と結果、target_idsには図で掘り下げる本文・具体値の説明先を書く。全図の同じ定型文で埋めず、図の問いに答えるために何を入れ、何を別図へ渡すかを個別に決める。

これらは図種を増やす指示ではありません。現正本が求める問い・関係・具体物の照合を、型・凡例・停止後の結果・元モデルの余白まで実施するための確認手順です。

## レビュー後の指示追加との区別

親担当は本レビューの指摘を受け、正本のexplanation-patterns.mdとacceptance.mdへ汎用対策を追加しました。今回のgradingは追加前に制作された初回4成果物をそのまま採点しています。追加指示で成果物が改善するかは再生成・再評価しておらず、改善検証済みとは扱いません。
