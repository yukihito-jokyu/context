# 旧版成果物の独立レビュー

2026年10月11日。旧版の依頼文、HTML本文、図モデル、coverageを照合した。parent-static-previewsの静的PNGをすべてview_imageで視認した。これらのPNGはCSSカスタムプロパティを派生プレビュー内で解決した診断画像であり、標準ブラウザの表示やPNG出力と同じであるとは判定していない。原成果物、スキル、モデルは変更していない。

新版貸出はこのレビュー担当が作成したため採点対象外。旧版貸出と他の旧版をこの担当が作成したことはない。新版との差や型の種類数、ノード数、diagram-planの有無を採点基準にせず、親から指定された共通期待値5項目のみで評価した。

## 結果

| 旧版の題材 | 合格 | 不合格 | 合格率 |
| --- | ---: | ---: | ---: |
| 非同期API | 3/5 | 2 | 0.6 |
| 備品貸出 | 4/5 | 1 | 0.8 |
| 自然の水循環 | 2/5 | 3 | 0.4 |
| 売上集計 | 4/5 | 1 | 0.8 |

各題材の判定と個別根拠はold_skill/grading.jsonに保存した。5項目の合格率は期待値の対応状況であり、全体的な品質を精密な数値へ変換したものではない。

## 全体表示と拡大切替

四題材とも図をdiagram-scrollへ置き、700px以下の幅で図の最小幅を1000pxへ固定している。

[APIのindex.html 6行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/old_skill/outputs/index.html:6)

> `.diagram-scroll .archify-overview-image{min-width:1000px}`

[貸出のindex.html 6行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/equipment-loan/old_skill/outputs/index.html:6)と[水循環のindex.html 6行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/old_skill/outputs/index.html:6)にも同じ指定がある。すべての図のボタンにはdata-diagram-zoomがあり、JavaScriptはボタンを表示する。

[APIのindex.html 60行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/old_skill/outputs/index.html:60)

> `button.hidden = false;`

この静的構造は「初期枠内に全体を表示し、標準の読み取りサイズ切替を追加しない」という期待値に合わない。狭い画面の実表示は確認していないため、はみ出しを実ブラウザで観測したという記録ではない。

## 非同期APIの往復

本文と通信例は、同じrequestKeyの再送、同じjobId、202が受付であること、ワーカーの成功・失敗、503後の最大2回再試行を説明している。架空APIと説明用のキー・JSON・URLも区別する。しかし概要図の接続はクライアントからサーバーへ、サーバーからワーカーへという片道で、202とjobIdの返却、GETの状態応答、ワーカーの保存先への戻りがない。

[overview.model.json 53行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/old_skill/outputs/overview.model.json:53)

> `"from": "client", "to": "server", "label": "POST / GET"`

[example.model.json](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/async-api/old_skill/outputs/example.model.json)も、POST、202返却、ワーカー成功保存、GETという列を示す。条件図の再試行停止と状態図の成功・失敗分岐は保たれるが、本文の通信の往復を図から追うには不足がある。図の型がworkflowであること自体を不合格理由とはしていない。

## 備品貸出の対応

本文とモデルはCAM-03、10月11日の貸出、7日後の10月18日期限、三条件を一致させる。条件図は成功と不成立の終了を分け、状態図は期限内の返却と延滞後の返却を分ける。本文と表は記録、在庫、新規貸出制限の別々の変化を説明している。プログラムや比較相手、正式帳票の追加は見られなかった。全体表示に関する一項目だけを不合格とした。

documents.pngは細い文字帯として見えたが、原documents.svgにはviewBox1569×304、五つのdata-node-id、枠と接続がある。派生プレビューの見え方から原成果物の図欠落と断定していない。表示確認が必要な項目として残す。

## 水循環の具体例の結末

本文の第五段階は川から海への帰還を述べる。

[page-model.json 31行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/old_skill/outputs/page-model.json:31)

> `⑤ 川から海へ` / `河川水の一部が海へ戻ります。`

ところが図の⑤は川の水であり、最後の矢印は地下水から川への流出で終わる。

[example.model.json 69行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/old_skill/outputs/example.model.json:69)

> `"label": "⑤川の水"`

[example.model.json 93行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/old_skill/outputs/example.model.json:93)

> `"from": "ex-ground", "to": "ex-river", "label": "地下水が川へ"`

概要図には川から海への戻りがあるため、循環全体が欠落したとは扱わない。同じ例・同じ第五段階の結末の対応が欠けるため、本文と図の結果一致の期待値を不合格とした。

条件図は降水条件と土壌・斜面・植生を直列に結び、経路の選択肢から川への到着へ無条件に結ぶ。

[conditions.model.json 79行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/water-cycle/old_skill/outputs/conditions.model.json:79)

> `"from": "split-condition", "to": "delay-condition", "label": "水が遅れて川へ"`

本文は、条件によって水量と時期が変わること、葉の水が蒸発すれば地下へ入る前に大気へ戻ることを説明する。条件群と選択肢の関係を全て川へ行く一本の順序にすると、本文が限定した成立条件を図が保持できない。型の名前ではなく、この無条件の関係を不合格理由とした。

## 検証の限界

四題材のHTMLは図をdata URIへ内包し、内部ハッシュリンクとcoverageの説明先IDに欠落がないことを静的に確認した。本文が示す資料の範囲と仮定も読んだ。リンク遷移、再生、一時停止、ブラウザ履歴、印刷、JavaScript無効、狭幅と広幅の実表示・文字の読みやすさは未検証。ブラウザを起動せず、別経路での回避もしていない。

各題材各条件一回の試行であり、生成の安定性、平均的な改善量、今後の再現率は証明しない。今回観測した成果物に対する適合と不適合だけを示す。

## 売上集計の対応

売上集計も全ページのparent-static-previewsをview_imageで視認し、本文・モデル・指定5行を照合した。取込処理はA3のxを隔離し、2件目のA1を重複記録へ保存する。採用されるのはA1・A2・A4であり、合計2000・500は図と本文で一致する。

[example.model.json 77行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/old_skill/outputs/example.model.json:77)

> `"label": "2000 と 500"`

隔離・重複の枝は集計へ戻らず、採用行だけがdaily_salesへ保存され、レポートは保存結果を読む。保存内容の表示例をDB構造とせず、通貨・保存方式・再実行ルールを補わない。HTMLは内部リンクと画像を保持する。

全体表示と標準拡大切替は他の三題材と同じ不適合がある。

[index.html 6行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/old_skill/outputs/index.html:6)

> `.diagram-scroll .archify-overview-image{min-width:1000px}`

[index.html 67行目](<user-home>/Documents/github_projects/context/explain-html-workspace/iteration-1/sales-pipeline/old_skill/outputs/index.html:67)

> `button.hidden = false;`

静的DOM解析で5個のdata-diagram-zoomボタンと5個のdiagram-scrollを確認した。この一項目を不合格とし、4/5とした。example/detailsの派生プレビューが文字帯として見えた点は、元SVGにノードと枠・接続があることを確認したため、図の欠落としては数えていない。
