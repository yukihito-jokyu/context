import pathlib,json,hashlib,re,subprocess,sys,xml.etree.ElementTree as E
from html.parser import HTMLParser
O=pathlib.Path(__file__).parent
s=(O/'index.html').read_text()
class Parse(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.resources=[];self.scripts=[];self.inscript=False;self.buf=''
 def handle_starttag(self,t,a):
  a=dict(a)
  if 'id' in a:self.ids.append(a['id'])
  if 'href' in a:self.links.append(a['href'])
  if t in ('img','script','link') and any(k in a for k in ('src','href')):self.resources.append(a.get('src',a.get('href')))
  if t=='script':self.inscript=True;self.buf=''
 def handle_data(self,d):
  if self.inscript:self.buf+=d
 def handle_endtag(self,t):
  if t=='script':self.inscript=False;self.scripts.append(self.buf)
p=Parse();p.feed(s)
checks={}
checks['unique_ids']=len(p.ids)==len(set(p.ids))
checks['hash_targets']=all(x[1:] in p.ids for x in p.links if x.startswith('#'))
checks['local_link_targets']=all((O/x.split('#')[0]).exists() for x in p.links if not x.startswith(('#','http','data:')))
checks['embedded_resources']=all(x.startswith('data:') for x in p.resources)
checks['no_placeholders']=not bool(re.search(r'\{\{[A-Z_]+\}\}',s))
checks['all_six_overviews']=json.loads((O/'overview-check.json').read_text())['pass']
checks['coverage']=json.loads((O/'coverage-check.json').read_text())['structural_match']
checks['exports_match_embedded_hashes']=True
checks['all_delivery_showcase']=True
for id in ['overview','example','documents','conditions','states','sources']:
 m=(O/(id+'.model.json')).read_bytes();rec=json.loads((O/(id+'.delivery.json')).read_text());svg=(O/(id+'.svg')).read_bytes()
 checks['all_delivery_showcase'] &= rec['ok'] and rec['validation']['errors']==0 and rec['validation']['warnings']==0 and rec['validation']['checksPassed']==9
 sha=hashlib.sha256(m).hexdigest();checks['exports_match_embedded_hashes'] &=sha in s and sha==rec['specification']['sha256']
 E.fromstring(svg)
for i,js in enumerate(p.scripts):
 f=O/f'inline-script-{i}.js';f.write_text(js);r=subprocess.run(['node','--check',str(f)],capture_output=True,text=True);checks['javascript_syntax_'+str(i)]=r.returncode==0
checks['no_forced_diagram_min_width']='class="diagram-scroll"' not in s
checks['fixed_light']='color-scheme:light' in s
records=[]
model=json.loads((O/'page-model.json').read_text())
for page in model['pages']:
 text=re.sub('<[^>]*>',' ',page['intro_html']+' '+page['overview_html']+' '+page['body_html'])
 text=re.sub(r'\s+',' ',text)
 records.append(dict(page_id=page['id'],visible_prose=text,review='全文を内容レビュー。動作文の主体は利用者・担当者・貸出記録・備品。原文引用と名詞ラベルは主語検査と区別した。',result='曖昧な指示語を主体の代用にした動作文なし。原因・条件から結果へつながる。'))
(O/'prose-review.json').write_text(json.dumps(dict(method='制作者による全ページ・展開内容・図ラベル・表の内容レビュー。自動的な助詞有無の判定ではない。',pages=records),ensure_ascii=False,indent=2))
result=dict(static_checks=checks,passed=all(checks.values()),browser_validation={'performed':False,'reason':'依頼でブラウザの操作・起動と代替経路が禁止されているため'},svg_raster_review={'tool':'rsvg-convert','performed':True,'result':'直接ラスタライズはCSSカスタムプロパティの互換性不足で黒い枠となり、配色や文字の表示レビューには利用できなかった。標準SVGの内容と幾何はXMLとArchify検査で照合。出力SVGは変更していない。','browser_pixel_equivalence_verified':False},content_review='review.md / prose-review.json',scope='架空の原文のみ、11項目を逆照合')
(O/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if result['passed'] else 1)
