import json,pathlib
O=pathlib.Path(__file__).parent
for id in ['overview','conditions']:
 p=O/(id+'.model.json');m=json.loads(p.read_text())
 for n in m['nodes']:n['width']=250
 p.write_text(json.dumps(m,ensure_ascii=False,indent=2))
for id in ['documents','sources']:
 p=O/(id+'.model.json');m=json.loads(p.read_text())
 for c in m['components']:c['size']=[290,105]
 p.write_text(json.dumps(m,ensure_ascii=False,indent=2))
p=O/'states.model.json';m=json.loads(p.read_text());m['meta']['viewBox']=[1300,780]
m['transitions'][0]['route']='straight'
p.write_text(json.dumps(m,ensure_ascii=False,indent=2))
