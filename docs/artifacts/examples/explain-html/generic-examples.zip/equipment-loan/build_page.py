import pathlib,json,base64,html,hashlib,xml.etree.ElementTree as E
O=pathlib.Path(__file__).parent
labels={'overview':'全体像','example':'具体例の動き','documents':'手続きと書類','conditions':'条件と例外','states':'状態と返却','sources':'資料との対応'}
ns={'s':'http://www.w3.org/2000/svg'}
node_targets={
'overview':{'present':'overview-input','check':'conditions-detail','lend':'documents-record','return':'states-detail','deny':'conditions-stop'},
'example':{'present':'example-s1','check':'example-s2','record':'example-s3','hand':'example-s4'},
'documents':{'card':'documents-input','staff':'documents-check','record':'documents-record','stock':'documents-stock'},
'conditions':{'check':'conditions-detail','lend':'conditions-pass','deny':'conditions-stop'},
'states':{'open':'states-open','late':'states-late','closed':'states-closed'},
'sources':{'source':'sources-original','explain':'sources-coverage','state':'sources-assumptions','review':'sources-validation'}}
readers={
'overview':'左から、提示・確認・貸出・返却を読みます。下の枝は、条件が成立せず担当者が貸出を終える経路です。',
'example':'①から④へ、CAM-03を渡すまでの一回の手続きを読みます。三条件が成立しない場合は、この成功例の③と④へ進みません。',
'documents':'会員証と番号は利用者が提示する入力です。矢印は担当者による提示の受領、記録への操作、在庫への操作を示し、書類同士の時間順を意味しません。',
'conditions':'担当者は三条件をまとめて判定します。成立側だけが貸出へ進み、不成立側は理由の説明で終わります。',
'states':'CAM-03の一件の貸出記録を追います。期限内の返却と延滞後の返却は、どちらも記録閉鎖へ進みます。延滞は必ず通る状態ではありません。',
'sources':'原文が説明と状態例の根拠になります。説明と例は対応表で原文に照合します。矢印は根拠と照合の関係で、貸出の手順ではありません。'}

def rectangle(g):
 for r in g.iter():
  if r.tag.endswith('rect') and all(a in r.attrib for a in ['x','y','width','height']):return {k:r.attrib[k] for k in ['x','y','width','height']}
 return None

def overview(id):
 raw=(O/(id+'.svg')).read_bytes();r=E.fromstring(raw);vb=r.attrib['viewBox'];v=list(map(float,vb.split()));sha=hashlib.sha256((O/(id+'.model.json')).read_bytes()).hexdigest()
 nodes=[g for g in r.iter() if 'data-node-id' in g.attrib]; hotspots='';rects={}
 for g in nodes:
  n=g.attrib['data-node-id'];rect=rectangle(g)
  if not rect or n not in node_targets[id]:continue
  rects[n]=rect;x,y,w,h=[float(rect[k]) for k in ['x','y','width','height']]
  hotspots+=f'<a class="diagram-hotspot" href="#{node_targets[id][n]}" aria-label="{html.escape(g.attrib.get("data-node-label",n))}の説明へ" style="left:{x/v[2]*100:.4f}%;top:{y/v[3]*100:.4f}%;width:{w/v[2]*100:.4f}%;height:{h/v[3]*100:.4f}%"></a>'
 flow='';controls=''
 if id=='example':
  captions=['利用者は10月11日に会員証とCAM-03の番号を提示します。','担当者は三条件を確認し、すべて成立すると判断します。','担当者は貸出日10月11日、期限10月18日の記録を作ります。','担当者は記録作成後、CAM-03を利用者へ渡します。']
  flow=f'<svg class="trace-svg" viewBox="{vb}" aria-hidden="true">'
  for i,n in enumerate(['present','check','record','hand']):
   rect=rects[n];attrs=' '.join(f'{k}="{v}"' for k,v in rect.items());flow+=f'<rect {attrs} class="stage-highlight" data-flow-stage="{i}"/>'
  for e in r.iter():
   if e.tag.endswith('path') and 'data-edge-id' in e.attrib:flow+=f'<path class="trace-signal" data-flow-edge="{e.attrib["data-edge-id"]}" d="{e.attrib["d"]}" pathLength="1" aria-hidden="true"/>'
  flow+='</svg>'
  controls='<div class="flow-controls" hidden><button type="button" data-flow-action="play">再生</button><button type="button" data-flow-action="pause">一時停止</button><button type="button" data-flow-action="reset">全体を表示</button>'
  for i,c in enumerate(captions):controls+=f'<button type="button" data-flow-select="{i}" data-flow-caption="{c}" data-flow-edges="{("edge"+str(i)) if i<3 else ""}">{i+1}段階</button>'
  controls+='</div><p class="flow-status" aria-live="polite">全体の手続きを表示しています。</p><p class="flow-note">再生は説明用の速さです。窓口でかかる時間を表しません。</p>'
  # Keep the real edge geometry; the final handover stage carries no following path.
 targets=list(dict.fromkeys(node_targets[id].values()))
 links=' '.join(f'<a href="#{t}">{html.escape(next(k for k,v in node_targets[id].items() if v==t))}の説明</a>' for t in targets)
 # Use human labels in the accessible text below the graphic.
 linknames={'present':'提示','check':'確認','lend':'貸出','return':'返却','deny':'貸出しない場合','record':'貸出記録','hand':'引渡し','card':'提示するもの','staff':'担当者の確認','stock':'在庫','open':'期限内','late':'延滞','closed':'記録閉鎖','source':'原文','explain':'対応表','state':'仮定と未指定事項','review':'検証範囲'}
 links=' '.join(f'<a href="#{t}">{linknames[next(k for k,v in node_targets[id].items() if v==t)]}</a>' for t in targets)
 return f'<div class="concern-whole-map" data-concern-overview="{id}"><p class="prose">{readers[id]}</p><figure '+('data-flow-diagram ' if id=='example' else '')+f'><div class="archify-overview-image"><img class="whole-map-image" src="data:image/svg+xml;base64,{base64.b64encode(raw).decode()}" alt="{html.escape(readers[id])}" data-archify-model-sha256="{sha}" data-archify-preset="editorial" data-archify-export="{id}.svg"/>{flow}{hotspots}</div>{controls}<figcaption>図の枠を選ぶと、対応する説明へ移動できます。<a href="{id}.svg">原図</a>・<a href="{id}.model.json">生成元モデル</a></figcaption></figure><div class="diagram-links">{links}</div></div>'

def p(text):return '<p>'+text+'</p>'
def block(id,title,text):return f'<section id="{id}" tabindex="-1"><h3>{title}</h3>{text}</section>'
def source():return ' <a href="#sources-original">根拠：提供された原文</a>'
intro={
'overview':'<p class="prose lead">担当者は三条件をすべて確認してから貸し出し、返却を受けて記録を閉じます。</p><p class="prose">このページは架空の備品貸出制度を説明します。利用者が持ち込む会員証と備品番号を入口に、担当者の確認、貸出、返却までを見渡します。</p>',
'example':'<p class="prose lead">2026年10月11日の貸出なら、返却期限は10月18日です。</p><p class="prose">同じ利用者がCAM-03を借りる成功例を追います。会員証は有効、未返却の期限超過はなし、CAM-03は在庫にあると仮定します。</p>',
'documents':'<p class="prose">利用者は会員証と備品番号を示し、担当者は確認した条件と貸出記録を手続きにつなげます。原文は専用の申請書や書式を指定していません。</p>',
'conditions':'<p class="prose lead">一つでも条件が成立しなければ、担当者は貸出せず終了します。</p><p class="prose">担当者が貸出前に確認する条件は、会員証の有効性、未返却の期限超過がないこと、対象備品の在庫です。確認の順番は原文で指定されていません。</p>',
'states':'<p class="prose">貸出記録、備品の在庫、利用者の新規貸出制限は、それぞれ異なる状態です。図は一件の記録を追い、本文は返却で三つの状態がどう変わるかをつなげます。</p>',
'sources':'<p class="prose">今回の根拠はユーザーが示した架空制度の原文だけです。このページは原文の規則と説明先を結び、具体例の仮定と未指定の細則を区別します。</p>'}
body={}
body['overview']='<div class="prose">'+block('overview-detail','借りる前と返すとき',p('担当者は、備品を渡す前に利用者と備品の条件を確認します。担当者が期限を記録するため、期限を過ぎた未返却も、新しい貸出の判定に使えます。')+source())+block('overview-input','利用者が窓口へ持っていくもの',p('利用者は会員証と、借りたい備品の番号を担当者へ提示します。CAM-03を借りる場合も、担当者は会員証とCAM-03という番号の両方を受け取ります。'))+p('利用者が返却すると、担当者は貸出記録を閉じ、備品を在庫へ戻します。利用者が延滞していた場合は、延滞記録の閉鎖によって新規貸出の制限も解除されます。')+p('<a href="#example">10月11日の具体例へ</a>進むと、期限と貸出記録を実際の日付で確認できます。')+'</div>'
body['example']='<div class="prose">'+block('example-detail','10月11日の貸出を四段階で追う',''.join(block('example-s'+str(i),str(i)+'．'+title,f'<div data-flow-stage="{i-1}">{p(text)}</div>') for i,title,text in [(1,'利用者が提示する','利用者は2026年10月11日に会員証と備品番号CAM-03を窓口へ提示します。'),(2,'担当者が条件を確認する','担当者は会員証が有効で、未返却の期限超過がなく、CAM-03が在庫にあることを確認します。この三条件の成立は説明用の仮定です。'),(3,'担当者が記録を作る','担当者は貸出日2026年10月11日と、貸出日から7日後の期限2026年10月18日を貸出記録に残します。10月11日から7日を足して10月18日になることは、原文の規則をこの日付へ適用した結果です。'),(4,'担当者が備品を渡す','担当者は貸出記録を作成した後、CAM-03を利用者へ渡します。CAM-03は貸出中となり、窓口の在庫にはありません。')]))+source()+p('貸出した同じCAM-03が戻る場面は、<a href="#states">状態と返却</a>で追います。期限内返却と延滞後返却は選択可能な別経路であり、この一回の例で両方が起きるわけではありません。')+'</div>'
body['documents']='<div class="prose">'+block('documents-detail','提示するものと担当者が扱う記録',p('会員証は有効性を確認するための提示物です。備品番号は、在庫を確認し貸し出す対象を指定します。貸出記録は、担当者が貸出と返却を対応づける具体物です。')+source())+block('documents-input','利用者の提示物',p('利用者は会員証とCAM-03の番号を示します。原文は会員証の有効性を調べる方法や、別の申請用紙の記入を指定していません。'))+block('documents-check','担当者の確認',p('担当者は会員証の有効性を確認します。担当者は未返却の期限超過がないかを確認し、CAM-03が在庫にあるかを確認します。確認に使う台帳の名称や保存形式は、原文にはありません。'))+block('documents-record','貸出記録の記入イメージ',p('以下は規則の対応を読むための記入例です。原文で確定している値は貸出日と期限で、備品番号や状態の並べ方は説明用の表示です。正式な帳票を追加したものではありません。')+'<table><thead><tr><th>記録の項目</th><th>貸出直後の例</th></tr></thead><tbody><tr><td>対象備品</td><td>CAM-03</td></tr><tr><td>貸出日</td><td>2026年10月11日</td></tr><tr><td>期限</td><td>2026年10月18日</td></tr><tr><td>記録の状態</td><td>未返却・記録が開いている</td></tr></tbody></table>'+p('利用者がCAM-03を返却すると、担当者はこの貸出に対応する記録を閉じます。原文は閉じた記録を削除するとは述べていません。'))+block('documents-stock','備品の在庫',p('担当者は貸出前にCAM-03の在庫を確認します。担当者がCAM-03を渡した後は貸出中となり、担当者が返却を受けて在庫へ戻すまで、CAM-03は窓口の在庫にありません。'))+'</div>'
body['conditions']='<div class="prose">'+block('conditions-detail','三条件はすべて必要',p('担当者は、下の三つがすべて成立した場合だけ貸し出します。一つの成立でほかの確認を省略することはできません。')+'<table><thead><tr><th>担当者が確認する条件</th><th>不成立の場合の理由</th></tr></thead><tbody><tr><td>会員証が有効である</td><td>会員証が無効である</td></tr><tr><td>未返却の期限超過がない</td><td>期限を過ぎた未返却がある</td></tr><tr><td>対象備品が在庫にある</td><td>対象備品が在庫にない</td></tr></tbody></table>'+source())+block('conditions-pass','すべて成立した場合',p('担当者は貸出日から7日後を期限として貸出記録を作り、備品を利用者へ渡します。期限超過のない貸出中の記録が存在するだけでは、原文の延滞条件には当たりません。ほかの貸出数制限は原文にありません。'))+block('conditions-stop','いずれかが不成立の場合',p('担当者は備品を貸し出さず、利用者へ理由を伝えて手続きを終了します。この経路では成功側の貸出記録作成と備品の引渡しへ進みません。')+p('会員証が無効な場合、担当者は会員証が無効なことを理由として伝えます。CAM-03が在庫にない場合、担当者はCAM-03が在庫にないことを理由として伝えます。複数条件が不成立のときに理由をどの順番で伝えるかは未指定です。'))+block('conditions-release','延滞の解除後も、担当者は三条件を確認する',p('利用者が延滞した備品を返し、担当者が延滞記録を閉じると、その延滞による新規貸出制限は解除されます。新しい貸出では担当者が会員証の有効性と対象備品の在庫も確認します。複数の延滞がある場合の解除の細則は原文にないため、この説明は一件の延滞で追います。'))+'</div>'
body['states']='<div class="prose">'+block('states-detail','同じ記録を返却まで追う',p('貸出直後の記録は開いています。利用者が期限内に返すか、未返却で期限を過ぎるかによって、記録の経路が分かれます。どちらの場合も、担当者は返却時に記録を閉じてCAM-03を在庫へ戻します。')+source())+block('states-open','期限内の貸出中',p('10月11日に借りたCAM-03の期限は10月18日です。期限を過ぎていない間は、この貸出は延滞ではありません。利用者が10月17日に返す例では、担当者は記録を閉じ、CAM-03を在庫へ戻します。10月17日の返却日は説明用の仮定です。'))+block('states-late','期限を過ぎても未返却なら延滞',p('利用者が未返却のまま期限を過ぎると、この貸出は延滞になり、新規貸出は止まります。10月19日にCAM-03が未返却である例なら、貸出記録は開いたまま、CAM-03は貸出中、利用者の新規貸出には制限があります。10月19日まで未返却という状況は説明用の仮定です。'))+block('states-closed','返却で記録と在庫を戻す',p('利用者が10月20日にCAM-03を返却する例では、担当者は延滞記録を閉じてCAM-03を在庫へ戻します。担当者が延滞記録を閉じると、その延滞による新規貸出制限は解除されます。10月20日の返却日は説明用の仮定です。')+p('記録を閉じたこの貸出が、次の貸出として再び開くとは説明しません。利用者が次に借りるときは、担当者が再度三条件を確認し、新しい貸出記録を作ります。'))+block('states-boundary','期限の細かな境界',p('原文は7日後という期限日を指定しますが、期限日の締切時刻、窓口の休業日、延長、紛失や破損の扱いは指定していません。したがって10月18日の何時から延滞になるかは、この説明だけでは決まりません。'))+'</div>'
items=[('present','提示物','overview-input'),('valid','会員証の有効性','conditions-detail'),('no-late','未返却の期限超過なし','conditions-detail'),('stock','備品の在庫','documents-stock'),('deny','不成立なら理由を伝えて終了','conditions-stop'),('record','7日後を期限として記録作成','documents-record'),('hand','記録作成後の引渡し','example-s4'),('return','返却時の記録閉鎖・在庫復帰','states-closed'),('late','未返却の期限超過・新規貸出停止','states-late'),('release','延滞記録閉鎖で制限解除','conditions-release'),('date','10月11日・CAM-03の具体例','example-detail')]
body['sources']='<div class="prose">'+block('sources-detail','確認範囲',p('このHTMLは2026年10月11日に提供された原文の規則を説明します。実在する施設の利用規則や法律を根拠としていません。外部の制度を補っていません。'))+block('sources-original','保存した一次入力',p('<a href="source.txt">依頼原文を開く</a>。以下に制度の全文を再掲します。')+'<blockquote>'+html.escape((O/'source.txt').read_text())+'</blockquote>')+block('sources-coverage','規則と説明先',p('原文の各規則を下の説明先へ照合しました。説明先では主体、条件、結果を文章で示しています。')+'<ul>'+''.join(f'<li><a href="#{target}">{name}</a></li>' for _,name,target in items)+'</ul>'+p('<a href="coverage.json">機械検査用の項目対応表</a>にも同じ対応を保存しています。'))+block('sources-assumptions','確認した規則・適用結果・説明用の仮定',p('確認した規則は三条件、7日後の期限、貸出記録、引渡し、返却、延滞、新規貸出制限と解除です。10月18日という期限は、7日後の規則を10月11日に適用した結果です。')+p('成功例の三条件の成立、10月17日の期限内返却、10月19日の未返却、10月20日の返却、貸出記録の表形式は説明用の仮定です。期限の時刻、確認の順番、複数延滞の解除細則、休業日、延長、紛失・破損の対応は原文で確認できません。'))+block('sources-validation','確認できたことと未確認のこと',p('制作時に、六枚の図の型付きモデルと配布成果物を静的に検査しました。原文との項目照合と文章の内容レビューも行いました。標準SVGは、同梱の標準関数を限定DOMアダプターで実行した出力です。')+p('ブラウザの起動と操作は禁止されているため、ブラウザでの表示、ページ移動、再生、印刷、狭い画面の見え方は未検証です。SVGの標準ブラウザ出力とのピクセル一致と標準PNGも未確認です。')+p('<a href="validation.json">静的検査記録</a>・<a href="review.md">内容レビュー記録</a>'))+'</div>'
model=dict(title='備品貸出のしくみ',scope='架空制度／提供原文のみ／2026年10月11日／CAM-03の例',groups={'start':'仕組みを読む'},pages=[dict(id=id,label=label,group='start',intro_html=intro[id],overview_html=overview(id),body_html=body[id]) for id,label in labels.items()])
(O/'page-model.json').write_text(json.dumps(model,ensure_ascii=False,indent=2))
coverage=dict(scope='ユーザーが提供した架空制度の全規則。確認日2026-10-11',sources=[dict(url='source.txt',title='提供された依頼原文')],items=[dict(key=k,topic='備品貸出制度',specification=name,source_url='source.txt',target_id=t,status='explained') for k,name,t in items])
(O/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2))
# Refresh design memo from final frozen model definitions, without editing models.
plan=json.loads((O/'diagram-plan.json').read_text())
for d in plan['diagrams']:
 m=json.loads((O/d['model_path']).read_text());d['entities']=m.get('nodes',m.get('components',m.get('states')));d['relations']=m.get('edges',m.get('connections',m.get('transitions')))
(O/'diagram-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
