import json,pathlib,shutil
O=pathlib.Path(__file__).parent
shutil.copyfile(O.parents[1]/'prompt.txt',O/'source.txt')
def save(name,m): (O/(name+'.model.json')).write_text(json.dumps(m,ensure_ascii=False,indent=2))
def meta(t): return dict(title=t,locale='ja',quality_profile='showcase',visual_preset='editorial',animation='none')
def work(name,title,nodes,edges,main):
 m=dict(schema_version=2,diagram_type='workflow',meta=meta(title),lanes=[dict(id='normal',label='窓口の手続き'),dict(id='stop',label='貸出しない場合',variant='exception')],nodes=[],edges=[],mainPath=main)
 for id,label,col,lane,sub in nodes: m['nodes'].append(dict(id=id,label=label,col=col,lane=lane,type='external',sublabel=sub))
 for i,(a,b,label,role) in enumerate(edges): m['edges'].append(dict(id=f'edge{i}',from_=a,to=b,label=label,role=role))
 for e in m['edges']: e['from']=e.pop('from_')
 save(name,m)
work('overview','貸出から返却まで', [('present','利用者が提示',0,'normal','会員証・備品番号'),('check','担当者が確認',1,'normal','三条件を確認'),('lend','担当者が貸出',2,'normal','記録作成・備品を渡す'),('return','利用者が返却',3,'normal','担当者が記録・在庫を戻す'),('deny','担当者が終了',1,'stop','理由を伝え、貸出しない')], [('present','check','提示を受ける','main'),('check','lend','すべて成立','main'),('lend','return','利用後','main'),('check','deny','一つでも不成立','error')],['present','check','lend','return'])
work('example','CAM-03を借りる一回の例',[('present','① 利用者が提示',0,'normal','10/11・CAM-03'),('check','② 担当者が確認',1,'normal','三条件は成立と仮定'),('record','③ 担当者が記録',2,'normal','期限は10/18'),('hand','④ 担当者が渡す',3,'normal','CAM-03を利用者へ')],[('present','check','会員証・番号','main'),('check','record','すべて成立','main'),('record','hand','記録を作成後','main')],['present','check','record','hand'])
work('conditions','三条件が貸出の入口を決める',[('check','担当者が判定',0,'normal','有効・延滞なし・在庫あり'),('lend','担当者が貸出',1,'normal','記録作成と備品の引渡し'),('deny','担当者が終了',1,'stop','貸出せず理由を伝える')],[('check','lend','三条件すべて成立','main'),('check','deny','いずれか不成立','error')],['check','lend'])
def arch(name,title,labels,links):
 m=dict(schema_version=1,diagram_type='architecture',meta=meta(title),layout=dict(mode='grid',cols=2,cellW=290,cellH=105,gapX=210,gapY=110),components=[],connections=[])
 for i,(id,label,sub) in enumerate(labels): m['components'].append(dict(id=id,type='external',label=label,sublabel=sub,row=i//2,col=i%2))
 for i,(a,b,l) in enumerate(links): m['connections'].append(dict(id=f'edge{i}',from_=a,to=b,label=l))
 for e in m['connections']:e['from']=e.pop('from_')
 save(name,m)
arch('documents','担当者が資料と記録を対応づける',[('card','会員証・備品番号','利用者が提示するもの'),('staff','担当者','三条件を確認する'),('record','貸出記録','貸出日・期限・返却の記録'),('stock','備品の在庫','CAM-03の有無')],[('card','staff','利用者が提示'),('staff','record','担当者が参照・作成・閉鎖'),('staff','stock','担当者が確認・返却時に戻す')])
arch('sources','原文から説明と確認へ',[('source','架空制度の原文','今回の唯一の仕様資料'),('explain','手続き・書類・条件','原文の規則を説明する'),('state','状態と具体例','記録・在庫・制限を追う'),('review','対応表・確認記録','原文と説明を照合する')],[('source','explain','規則の根拠'),('source','state','状態変化の根拠'),('explain','review','説明先を照合'),('state','review','例と規則を照合')])
m=dict(schema_version=2,diagram_type='lifecycle',meta=meta('1件の貸出記録が閉じるまで'),subject=dict(label='CAM-03の1件の貸出記録',beginning='担当者が貸出記録を作る',ending='担当者が返却時に記録を閉じる',coverage='complete'),initial=['open'],terminal=['closed'],lanes=[dict(id='record',label='貸出記録')],states=[dict(id='open',kind='state',label='貸出中・期限内',lane='record',col=0,row=0,sublabel='CAM-03は利用者の手元'),dict(id='late',kind='state',label='延滞・未返却',lane='record',col=1,row=0,sublabel='新規貸出を止める'),dict(id='closed',kind='state',label='返却済み・記録閉鎖',lane='record',col=1,row=1,sublabel='CAM-03は在庫へ戻る')],transitions=[dict(id='overdue',kind='transition',from_='open',to='late',condition='未返却で期限を過ぎる'),dict(id='normal_return',kind='transition',from_='open',to='closed',event='利用者が期限内に返却'),dict(id='late_return',kind='transition',from_='late',to='closed',event='利用者が返却',action='担当者が延滞記録を閉じる')])
for e in m['transitions']:e['from']=e.pop('from_')
save('states',m)
plans=[]
questions={'overview':'貸出と返却はどうつながるか','example':'10月11日にCAM-03を借りると何が起きるか','documents':'提示するものと残す記録は何か','conditions':'どの条件で担当者は貸出を止めるか','states':'未返却、延滞、返却で何が変わるか','sources':'原文のどの規則をどこで説明するか'}
for p in O.glob('*.model.json'):
 m=json.loads(p.read_text());id=p.name.split('.')[0]
 plans.append(dict(id=id,page_id=id,role='overview',question=questions[id],takeaway=m['meta']['title'],type=m['diagram_type'],selection_reason='順序と分岐を表す' if m['diagram_type']=='workflow' else '状態ときっかけを表す' if m['diagram_type']=='lifecycle' else '情報と主体の関係を表す',scope='提供された架空の制度のみ',sources=['source.txt'],entities=m.get('nodes',m.get('components',m.get('states'))),relations=m.get('edges',m.get('connections',m.get('transitions'))),parent_diagram_id=None,model_path=p.name,target_ids=[id+'-detail']))
(O/'diagram-plan.json').write_text(json.dumps(dict(diagrams=plans),ensure_ascii=False,indent=2))
