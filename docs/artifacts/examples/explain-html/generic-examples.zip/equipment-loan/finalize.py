from pathlib import Path
O=Path(__file__).parent
p=O/'index.html';s=p.read_text()
# The original flow runtime searches within its root. The concern section includes
# both the diagram and the corresponding document/prose stages.
s=s.replace('<section id="example" class="concern-page"','<section id="example" data-flow-diagram class="concern-page"')
s=s.replace('<figure data-flow-diagram >','<figure>')
p.write_text(s)
