import json,re,subprocess,hashlib,csv
from pathlib import Path
from html.parser import HTMLParser
from decimal import Decimal
O=Path(__file__).resolve().parent
S=Path('<user-home>/Documents/github_projects/context/utils/skills/discovery/explain-html')
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.ids=[];self.links=[];self.images=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.append(d['id'])
  if t=='a':self.links.append(d.get('href',''))
  if t=='img':self.images.append(d)
p=Parser();raw=(O/'index.html').read_text();p.feed(raw)
assert len(set(p.ids))==len(p.ids)
for h in p.links:
 if h.startswith('#'):assert h[1:] in p.ids,h
 elif h and not re.match('https?://',h):assert (O/h).is_file(),h
assert len(p.images)==5 and all(x['src'].startswith('data:image/svg+xml;base64,') for x in p.images)
assert not re.search(r'<(?:script|link)[^>]+(?:src|href)=',raw)
assert '{{' not in raw
for i,s in enumerate(re.findall(r'<script>(.*?)</script>',raw,re.S)):
 f=O/f'inline-script-{i}.js';f.write_text(s);r=subprocess.run(['node','--check',str(f)],capture_output=True,text=True);assert r.returncode==0,r.stderr
# 検証用の最小計算器。数値の境界は仕様化せず、指定5行だけを計算する。
seen=set();accepted=[];duplicates=[];quarantine=[];totals={}
for n,row in enumerate(csv.DictReader((O/'input.csv').open()),1):
 reasons=[]
 if not row['order_id']:reasons.append('order_idの欠落')
 if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',row['day']):reasons.append('dayの形式不正')
 try:amount=Decimal(row['amount'])
 except:reasons.append('amountが数値でない')
 if reasons:quarantine.append({'line':n,'row':row,'reasons':reasons});continue
 if row['order_id'] in seen:duplicates.append({'line':n,'row':row});continue
 seen.add(row['order_id']);accepted.append({'line':n,'row':row});totals[row['day']]=totals.get(row['day'],Decimal(0))+amount
assert {k:int(v) for k,v in totals.items()}=={'2026-10-11':2000,'2026-10-12':500}
assert [x['line'] for x in accepted]==[1,2,5]
assert [x['line'] for x in duplicates]==[3] and [x['line'] for x in quarantine]==[4]
(O/'computed-example.json').write_text(json.dumps({'accepted':accepted,'duplicates':duplicates,'quarantine':quarantine,'daily_sales':{k:int(v) for k,v in totals.items()},'scope':'指定5行だけの再計算。未指定の数値・日付境界を定義する実装ではない。'},ensure_ascii=False,indent=2))
checks={}
for name,args in [('overviews',[str(S/'scripts/check_overviews.py'),str(O/'index.html')]),('coverage',[str(S/'scripts/check_coverage.py'),str(O/'index.html'),str(O/'coverage.json')]),('vendor',[str(S/'scripts/sync_vendor.py'),'--check'])]:
 r=subprocess.run(['python3',*args],capture_output=True,text=True);checks[name]={'exit_code':r.returncode,'receipt':json.loads(r.stdout)};assert r.returncode==0,r.stdout+r.stderr
models={}
for name in ['overview','example','storage','conditions','sources']:
 r=json.loads((O/(name+'.deliver.json')).read_text());assert r['ok'];models[name]={'showcase':r,'export':json.loads((O/(name+'.export.json')).read_text())}
receipt={'date':'2026-10-11','static_checks':checks,'archify':models,'embedded_images':5,'duplicate_ids':0,'broken_local_links':0,'inline_javascript_syntax':'pass','input_output_recalculation':'pass: accepted 1,2,5; duplicate 3; quarantine 4; 2000 / 500','browser':{'performed':False,'reason':'local file URL policy rejection; no browser/server bypass','not_verified':['wide/narrow actual layout','navigation and history runtime','play/pause and stages runtime','browser PNG pixel equivalence']},'index_sha256':hashlib.sha256((O/'index.html').read_bytes()).hexdigest()}
(O/'verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print('Static verification passed; browser verification not performed.')
