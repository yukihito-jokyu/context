# 資料取得記録

確認日: 2026-10-11。

- request-original.txtは依頼全文のコピー。
- usgs-requested.htmlは指定URLの直接取得で返った403応答。USGS本文として扱わない。
- web-source-response.jsonはwebツールから取得した現行Water cycleと地下水・浸透・凝結資料の応答を、そのまま保存した原文記録。ツールの行数・出典・抽出制限が含まれる。
- web-source-supplement.jsonは海・氷の資料および昇華・蒸発散URLのタイムアウト応答。
- web-source-search.jsonは昇華と蒸発散のUSGS検索取得本文。定義と条件をこの一次提供元の本文で確認した。

これらは取得できたツール応答の原文であり、すべてのページの完全HTMLスナップショットではない。指定URLと現行URLの本文一致やリダイレクトは確認できていない。
