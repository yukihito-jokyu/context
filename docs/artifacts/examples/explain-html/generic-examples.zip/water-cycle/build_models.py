import json
from pathlib import Path
O=Path(__file__).parent
specs={
'overview':('貯留場所を結ぶ水の移動',['海と大気','陸の表面','地下と河川'],[('ocean','海',0,0),('air','大気',0,2),('surface','地表',1,2),('ground','地下水',2,3),('river','河川・湖',2,1)],[('ocean','air','水が蒸発する'),('air','surface','雨・雪が降る'),('surface','ground','水が浸透する'),('surface','river','水が流出する'),('ground','river','水が湧き出す'),('river','ocean','水が海へ流れる')]),
'example':('森林に降った雨を追う',['雨のあと','土壌の中','川への出口'],[('rain','① 地表の雨水',0,1),('soil','② 土壌水',1,2),('runoff','② 地表流出',1,0),('aquifer','③ 地下水',2,3),('stream','④ 川',2,0)],[('rain','soil','水が浸透する'),('rain','runoff','水が地表を流れる'),('soil','aquifer','水が涵養する'),('runoff','stream','水が川に入る'),('aquifer','stream','地下水が流出する')]),
'details':('水の形と戻り道',['地表・植物','大気','降水・貯留'],[('liquid','液体の水',0,1),('plant','植物の水',0,3),('vapor','水蒸気',1,2),('cloud','雲の水滴・氷',2,2),('ice','雪・氷',2,0)],[('liquid','vapor','水が蒸発する'),('plant','vapor','植物が蒸散する'),('vapor','cloud','水が凝結する'),('cloud','ice','雪が降り積もる'),('ice','liquid','雪・氷が融ける')]),
'conditions':('条件が水の行き先を変える',['雨と地表の条件','分かれる経路','異なる結果'],[('raincond','雨量・土壌・斜面',0,1),('infil','浸透と貯留',1,0),('run','地表流出',1,2),('later','地下水と遅い流出',2,0),('fast','川への早い流出',2,2)],[('raincond','infil','条件が浸透を変える'),('raincond','run','条件が流出を変える'),('infil','later','水が地下へ進む'),('run','fast','水が地表を進む')]),
'sources':('根拠から説明と限界へ',['一次資料','説明の作成','読者の確認'],[('usgs','USGSの科学資料',0,0),('claim','確認した仕組み',1,0),('assume','説明用の仮定',1,2),('reader','出典と限界',2,1)],[('usgs','claim','資料が事実を支える'),('claim','reader','本文が根拠を示す'),('assume','reader','本文が仮定を示す')])}
plans=[]
for key,(title,stages,ns,fs) in specs.items():
 m={'schema_version':1,'diagram_type':'dataflow','meta':{'title':title,'locale':'ja','visual_preset':'editorial','quality_profile':'showcase','animation':'none'},'stages':[{'label':s} for s in stages],'nodes':[{'id':i,'type':'external','label':l,'stage':s,'row':r} for i,l,s,r in ns],'flows':[{'id':f'{key}-e{j}','from':a,'to':b,'label':l} for j,(a,b,l) in enumerate(fs)]}
 (O/'diagrams'/f'{key}.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
 plans.append({'id':key,'page_id':key,'role':'overview','question':title+'はどうつながるか','takeaway':title,'type':'dataflow','selection_reason':'物質の移動、または根拠の受け渡しを表す。横の段は配置であり全経路の一律の時系列ではない。','scope':'自然の水循環。具体例のみ森林流域を仮定。','sources':['https://www.usgs.gov/water-science-school/water-cycle'],'entities':[n[1] for n in ns],'relations':[list(f) for f in fs],'parent_diagram_id':None,'model_path':f'diagrams/{key}.json','target_ids':[f'{key}-text']})
(O/'diagram-plan.json').write_text(json.dumps({'diagrams':plans},ensure_ascii=False,indent=2))
