import base64,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path
O=Path(__file__).parent
S=Path('utils/skills/discovery/explain-html')
class Check(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.images=[];self.scripts=[];self.in_script=False;self.script=''
 def handle_starttag(self,t,a):
  d=dict(a)
  if d.get('id'):self.ids.append(d['id'])
  if t=='a':self.links.append(d.get('href',''))
  if t=='img':self.images.append(d)
  if t=='script':self.in_script=True;self.script=''
 def handle_data(self,s):
  if self.in_script:self.script+=s
 def handle_endtag(self,t):
  if t=='script':self.scripts.append(self.script);self.in_script=False
p=Check();content=(O/'index.html').read_text();p.feed(content)
issues=[]
for h in p.links:
 if h.startswith('#') and h[1:] not in p.ids:issues.append('Missing '+h)
for im in p.images:
 data=base64.b64decode(im['src'].split(',',1)[1]);path=O/im['data-archify-export'];assert data==path.read_bytes()
 key=path.stem;assert im['data-archify-model-sha256']==hashlib.sha256((O/'diagrams'/f'{key}.json').read_bytes()).hexdigest()
for i,s in enumerate(p.scripts):
 path=O/f'inline-script-{i}.js';path.write_text(s);r=subprocess.run(['node','--check',str(path)],capture_output=True,text=True);assert not r.returncode,r.stderr
results=[]
for command in [['python3',str(S/'scripts/check_overviews.py'),str(O/'index.html')],['python3',str(S/'scripts/check_coverage.py'),str(O/'index.html'),str(O/'coverage.json')],['python3',str(S/'scripts/sync_vendor.py'),'--check']]:
 r=subprocess.run(command,capture_output=True,text=True);results.append({'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
receipt={'date':'2026-10-11','html_sha256':hashlib.sha256(content.encode()).hexdigest(),'pages':5,'embedded_archify_svgs':len(p.images),'all_embedded_svgs_equal_original':True,'model_hashes_match':True,'broken_hash_links':issues,'script_syntax':'passed','checks':results,'browser_display':'not performed: policy restriction; no alternative browser/server used','interaction_runtime':'not performed; syntax and original script contracts inspected','static_raster':'rsvg produced black fills; this is an unsupported CSS-variable rendering path, not a browser screenshot. PNG not embedded.','visual_qa':'not established by original rsvg preview','standard_png_equality':'not verified','complete_source_url_identity':'not verified; requested URL timeout/403; same-provider current URL used'}
(O/'verification-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k not in ['checks']},ensure_ascii=False,indent=2))
