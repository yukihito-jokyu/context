# write-commit-message 収束テストの記録

このスキルの作成に関わっていない独立エージェント（Claude Code と Codex。起動できないときは Agent ツールの subagent）に同じ依頼を解かせ、出力の違い（揺れ）を測った記録である。生データは `dev/results/convergence/round-<R>/` にある。

## 条件

| 項目 | 値 |
|---|---|
| runner | TODO(skill-foundation): 使った runner（claude、codex、subagent）と、STEP-03 の表のどの行で選んだか |
| 1 runner あたりの人数 | |
| 課題 | `dev/evals.json` |
| 合格基準 | status が全員、課題の expect_status と同じ。check が全員通過。スキル自身や hooks の登録を変えたエージェント（失格）がいない。files・structure・names が基準以上。最後のラウンドのレビューの検出率が全見本で 1.0。V1〜V7 の未対処が0件 |

## ラウンドの一覧

| ラウンド | 課題 | status | files | structure | names | content | check | 失格 | V1〜V7 の未対処 |
|---|---|---|---|---|---|---|---|---|---|
| TODO(skill-foundation) | | | | | | | | | |

## レビューの検出率（最後のラウンド）

| 見本 | 決定 | 検出率 | 余計な指摘 | 一致 |
|---|---|---|---|---|
| TODO(skill-foundation): `review.md` の表を写す。reviews が無いスキルは「なし」 | | | | |

## ラウンド 1

### 揺れと分類

| # | 課題 | 揺れ | 分類 | 対処 |
|---|---|---|---|---|
| TODO(skill-foundation) | | | | |

## 結論

TODO(skill-foundation): 合格基準を満たしたか。満たさなかった場合は、残った揺れとその扱いを書く。
