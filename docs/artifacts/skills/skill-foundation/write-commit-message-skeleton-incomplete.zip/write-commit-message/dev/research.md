# write-commit-message の調査

スキルが前提にする事実（ツールのバージョン、コマンドの引数、入出力の形式、公式の書き方）を、出典付きで記録する。記憶で書かない。「確認の状態」は「確認済み」「確かめられない」「未確認」のどれかを書く（skill-foundation の references/research.md の3章）。「未確認」の項目が残っている間は、`skill_lint.py --final` が通らない。

## TODO(skill-foundation): 調べた対象の名前

- 確認方法：<実行したコマンドとその結果、または読んだ公式ページの URL。確認した日>
- 確認の状態：未確認
- 分かったこと：
- 使った決定：<決定のID>

<!-- basis が project の決定の根拠は、次のどちらかの行を項目に足す（skill-foundation の references/research.md の3章）
- 決まり：<決まりが書いてあるファイルと場所（CLAUDE.md の節、設定ファイルのキー）>
- 分布：<書き方 A> <件数>、<書き方 B> <件数>（数えたコマンド：`<コマンド>`）
-->
