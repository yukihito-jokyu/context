## 結果

skill-foundation: 中断（理由: ユーザー指定により受付と骨組み生成（フェーズ0・1）で停止。フェーズ1のlint結果を記録し、調査・決定・契約の実装・違反例・収束テスト・インストール・hooks登録・最終検査は未実施。スキルは未完成（status: building）。）

## 出力

- `.claude/skills/write-commit-message/SKILL.md`（skill-entry 作ったスキルの SKILL.md）

## 既定値で決めた値

- なし

## 入力で読めなかった値

- なし

## 検証

- 中断したため、検証していない

## 補足

- なし
