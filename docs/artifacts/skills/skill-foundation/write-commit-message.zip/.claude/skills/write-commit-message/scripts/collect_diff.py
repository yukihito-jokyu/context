#!/usr/bin/env python3
"""ステージ済みの差分を出す（IN-01、IN-02、STEP-01）。

出力: git diff --cached のテキスト。
終了コード: 0 成功、2 git の失敗、4 ステージ済みの変更が無い。
使い方: python3 collect_diff.py [--help]
"""
import argparse
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.parse_args()
result = subprocess.run(["git", "diff", "--cached", "--no-ext-diff", "--no-color"], capture_output=True, text=True)
if result.returncode:
    print(result.stderr.splitlines()[0] if result.stderr else "git diff の取得に失敗した", file=sys.stderr)
    sys.exit(2)
if not result.stdout.strip():
    print("ステージ済みの変更が無い", file=sys.stderr)
    sys.exit(4)
print(result.stdout, end="")
