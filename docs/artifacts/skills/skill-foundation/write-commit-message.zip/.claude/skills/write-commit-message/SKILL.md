---
name: write-commit-message
description: "ステージ済みの git diff を受け取り、日本語の1行コミットメッセージをUTF-8テキストに書く。「コミットメッセージを書いて」、「差分を日本語の1行にまとめて」、「ステージ済みの変更からコミット文を作って」、「この変更のコミットメッセージを考えて」、「write a Japanese commit message」と頼まれたときに使う。コミットの実行やプッシュには使わない（代わりに内容を確認してから git コマンドを実行するを使う）。"
---

# コミットメッセージを書く

<!-- BEGIN GENERATED:purpose -->
ステージ済みの git diff を受け取り、日本語の1行コミットメッセージをUTF-8テキストに書く
<!-- END GENERATED:purpose -->

## 1. 使う場面

<!-- BEGIN GENERATED:triggers -->
次のような依頼で使う。

- 「コミットメッセージを書いて」
- 「差分を日本語の1行にまとめて」
- 「ステージ済みの変更からコミット文を作って」
- 「この変更のコミットメッセージを考えて」
- 「write a Japanese commit message」

次の場合は使わない。

- コミットの実行やプッシュ → 代わりに: 内容を確認してから git コマンドを実行する

依頼の内容から自動で選ばれる。明示して呼ぶときは Claude Code では `/write-commit-message`、Codex では `$write-commit-message` と書く。
<!-- END GENERATED:triggers -->

## 2. 手順

1. 依頼から「3. 入力」を確認する。start の前に聞く項目が無いため、質問せずに手順2へ進む（CTL-03）。
2. `python3 <skill>/scripts/run.py start "<依頼文>"` を実行する（CTL-01）。
3. `python3 <skill>/scripts/collect_diff.py` を実行し、終了コード4か2なら IN-01 に従って中断する。終了コード0なら標準出力だけを材料にする。未ステージの変更や履歴を読まず、取得した差分の変更を要約する。git の書き込みコマンドを実行せず、利用者へメッセージを渡す（IN-01、IN-02、STEP-01、STEP-02）。
4. 見本 `assets/examples/commit-message.txt` の形で、日本語の1行の要約を書き、UTF-8の `.skill-runs/write-commit-message/out/commit-message.txt` に保存する。変更の対象と動作が差分に一致するかを確かめる（OUT-01、OUT-02、OUT-03、OUT-04、OUT-05）。
5. `python3 <skill>/scripts/run.py check` を実行する。指摘があれば出力を直し、check を実行し直す。整形の記録があればファイルを読み直す（CTL-02）。
6. `python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順5へ戻る。終了コード0なら、出力された本文をそのまま返答する（RPT-01）。

## 3. 入力

<!-- BEGIN GENERATED:inputs -->
入力の項目は無い。依頼文だけを `run.py start` に渡す。
<!-- END GENERATED:inputs -->

## 4. ルール

<!-- BEGIN GENERATED:decisions -->
| ID | ルール | 守らせ方 |
|---|---|---|
| IN-01 | `scripts/collect_diff.py` の終了コードが4なら `run.py abort --reason "ステージ済みの変更が無い"`、2なら `run.py abort --reason "git diff の取得に失敗した"` を実行する。終了コード0のときだけ出力を書く。 | script, doc: scripts/collect_diff.py と SKILL.md の手順3 |
| IN-02 | メッセージの材料は `scripts/collect_diff.py` の標準出力だけにする。未ステージの変更、コミット履歴、差分に無いファイルは読まず、取得した差分の変更内容を要約する。 | script, doc: scripts/collect_diff.py と SKILL.md の手順3 |
| STEP-01 | 手順は `run.py start`、`scripts/collect_diff.py`、メッセージの作成、`run.py check`、`run.py finish` の順にする。差分の取得は `collect_diff.py` が行う。 | script, doc: scripts/collect_diff.py と SKILL.md の手順2〜6 |
| STEP-02 | スキルが実行する git コマンドは `scripts/collect_diff.py` の `git diff --cached --no-ext-diff --no-color` だけにする。`git add`、`git commit`、`git push` は実行せず、メッセージを書いて利用者へ渡す。 | doc: SKILL.md の手順3 |
| OUT-01 | UTF-8のテキストを `.skill-runs/write-commit-message/out/commit-message.txt` の1ファイルに書く。 | validate: 契約の outputs.commit-message の path と count |
| OUT-02 | 見出し、箇条書き、コードブロックを付けず、空でないメッセージを1行だけ書く。末尾の改行は1つにする。 | validate, format: 契約の max_lines、require、forbid と final_newline |
| OUT-03 | 日本語の「<対象>を<動詞>する」の形で差分の変更を要約する。行末に句点を付けない。日本語の文字があることは検査し、差分との一致と文の形は完了前チェックリストで確かめる。 | validate, format, review: 契約の require と replace。完了前チェックリストで差分との一致を確かめる |
| OUT-04 | メッセージは1文字以上50文字以内にする。 | validate: 契約の line_length |
| OUT-05 | `[skip ci]`、`[ci skip]`、`[no ci]`、`[skip actions]`、`[actions skip]`、`skip-checks:true` を書かず、変更の要約だけを書く。 | validate: 契約の forbid |
| RPT-01 | 最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない。中断したときは、`run.py abort` が出力した本文を同じように使う。決めきれなかったことは、finish の前に `.skill-runs/<name>/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを本文の「## 補足」に入れる。 | runtime, validate, review: scripts/run.py の finish と abort が本文を組み立て、.skill-runs/<name>/report.md にも保存する。check と finish が notes.md の形を検査する |
| CTL-01 | 手順の最初に `run.py start`、出力を書いた後に `run.py check`、最後に `run.py finish` を実行する。`finish` が終了コード0で終わるまで、完了と返答しない。 | runtime, validate: scripts/run.py。finish は契約の検査に通らないと終了コード1で終わる |
| CTL-02 | `run.py start` から `run.py finish` までの間、スキルの保護ファイル（`SKILL.md`、`scripts/`、`assets/`、`references/`）と、プロジェクトに登録したこのスキルの hooks を変えない。出力が契約に合わないときは、出力の方を直す。保護ファイルが合格時の指紋（`assets/seal.json`）と違うと `run.py start` が終了コード1で止まるので、そのときは出力された指摘をユーザーに伝えて止まる。 | runtime, validate: scripts/run.py の start が保護ファイルのハッシュと hooks の登録を記録し、check と finish が比べる。`start --restart` は記録を最初の start から引き継ぐ。hooks が編集の前に止める。start は合格時の指紋と保護ファイルを比べ、違えば始めない |
| CTL-03 | ユーザーに聞くことは `run.py start` の前にまとめて聞く。start の後に聞く必要が出たときは、`run.py wait --question <質問>` を実行してから聞く。聞けない状況では既定値を使い、報告の「既定値で決めた値」に載せる。 | runtime, doc: scripts/run.py の start は、聞くべき入力が無いと終了コード3で止まり、質問を出力する。wait は hooks の強制を止める |
| CTL-04 | hooks は、このスキルの実行中（status: active）に、編集の後の検査、応答を終える前の検査、保護ファイルの編集の停止の3つを行う。実行していないときは、合格時の指紋があるスキル（`assets/seal.json` がある）の保護ファイルの編集に、Claude Code で確認を求めることだけを行う。ユーザーの発言を止めたり書き換えたりしない。 | runtime: scripts/hook.py。install.py が Claude Code（.claude/settings.json）と Codex（.codex/hooks.json）に登録する |
| CTL-05 | `run.py start` から `run.py finish` までの間に作る・変えるファイルは、「5. 出力の契約」の出力と `control.allow_changes` に挙げたものだけにする。作業用のメモや一時ファイルも、出力の置き場の外に作らない。 | runtime, validate: scripts/run.py の start が git の作業ツリーの状態を記録し、check と finish が比べる。編集の直後には hooks が知らせる |

理由・良い例・悪い例は [references/decisions.md](references/decisions.md) にある。
<!-- END GENERATED:decisions -->

## 5. 出力の契約

<!-- BEGIN GENERATED:contract -->
| 出力 | 置き場 | 件数 | 検査（ルールID） |
|---|---|---|---|
| commit-message コミットメッセージ | `{run}/out/commit-message.txt` | 1〜1 件（OUT-01） | 自動で直す: 末尾の改行を1つにする（OUT-02）。自動で直す: `。$` を「」に置き換える（OUT-03）。1 行以下（OUT-02）。`\S` に一致する行がある（空でない1行にする）（OUT-02）。`^(?:#\|[-*] \|```)` に一致する行が無い（見出し、箇条書き、コードブロックを付けない）（OUT-02）。`[ぁ-んァ-ヶ一-龠]` に一致する行がある（日本語の文字で書く）（OUT-03）。1行目は 50 文字以下（OUT-04）。`(?i)\[(skip ci\|ci skip\|no ci\|skip actions\|actions skip)\]\|skip-checks:\s*true` に一致する行が無い（CIを止める記法を書かない）（OUT-05） |

`{run}` は実行記録の置き場 `.skill-runs/write-commit-message` を指す。`run.py start` の前からあったファイルで、内容が変わっていないものは検査しない。

- 保護ファイルが実行中に変わっていない（CTL-02）
- 上の出力のほかに、start の後に変わったファイルが無い（CTL-05。git の作業ツリーで判定し、git が無いときは検査しない）
<!-- END GENERATED:contract -->

## 6. 完了前チェックリスト

<!-- BEGIN GENERATED:checklist -->
- [ ] OUT-03 日本語の「<対象>を<動詞>する」の形で差分の変更を要約する。行末に句点を付けない。日本語の文字があることは検査し、差分との一致と文の形は完了前チェックリストで確かめる。
- [ ] RPT-01 最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない。中断したときは、`run.py abort` が出力した本文を同じように使う。決めきれなかったことは、finish の前に `.skill-runs/<name>/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを本文の「## 補足」に入れる。
- [ ] `python3 <skill>/scripts/run.py finish` が終了コード0で終わった
<!-- END GENERATED:checklist -->

## 7. 報告

<!-- BEGIN GENERATED:report -->
最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない（RPT-01）。決めきれなかったことは、finish の前に `.skill-runs/write-commit-message/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを「## 補足」に入れる。中断するときは `run.py abort --reason <理由>` を実行し、abort が出力した本文を同じようにそのまま使う。本文の形は次のとおり。

```text
<出力 commit-message の本文>

---

## 結果

write-commit-message: 完了（検証に合格）

## 出力

- `<パス>`（<出力ID> <出力の名前>）

## 既定値で決めた値

- <項目>（<キー>）: <値>（無ければ「- なし」）

## 入力で読めなかった値

- <内容>（無ければ「- なし」）

## 検証

- `run.py finish`: 指摘 0 件

## 補足

- <notes.md の箇条書き。無ければ「- なし」>
```
<!-- END GENERATED:report -->

## 8. 制御の仕組み

<!-- BEGIN GENERATED:control -->
| 仕組み | いつ働くか | 何をするか |
|---|---|---|
| `scripts/run.py start` | 手順の始め | 入力を正規化し（表記ゆれ・全角・未知のキーを受け入れる）、既定値で補い、保護ファイルのハッシュと git の作業ツリーの状態を記録する。保護ファイルが合格時の指紋（`assets/seal.json`）と違えば始めない（終了コード1） |
| `scripts/run.py check` と `finish` | 出力を書いた後と最後 | 契約（`assets/contract.json`）の format で出力を直してから検査する。finish は通ったときだけ実行を終える |
| hooks の pre-tool | ファイルを編集する前 | 保護ファイルと実行記録の編集を止める（Claude Code は確認を求め、Codex は拒否する）。実行していないときも、合格時の指紋があるスキルの保護ファイルの編集に Claude Code で確認を求める |
| hooks の post-tool | ファイルを編集した後 | 出力に当たるファイルを format で直し、検査し、指摘を返す。出力でも変えてよいファイルでもなければ CTL-05 の指摘を返す |
| hooks の stop | 応答を終える前 | 出力全体を検査し、通るまで応答を終えさせない（最大 3 回。超えると status: failed） |
| hooks の prompt | ユーザーが発言したとき | 質問待ち（wait）を解くだけ。発言を止めたり書き換えたりしない |

hooks は、このスキルの実行中（`.skill-runs/write-commit-message/state.json` の status が active）だけ出力を検査する。hooks が無い環境でも、`run.py check` と `finish` が同じ検査をする。

hooks の登録: `python3 <skill>/scripts/install.py --project <プロジェクトのルート>`（Claude Code は `.claude/settings.json`、Codex は `.codex/hooks.json` に追記する。Codex では、追記した hooks を `/hooks` で信頼するまで動かない）

保護ファイル（スキルのディレクトリからの相対パス）: `SKILL.md`、`scripts/**`、`assets/**`、`references/**`

このスキル（ルール、契約、手順、スクリプト）を変えるときは、次の順にする。保護ファイルだけを直接書き換えると、合格時の指紋と違うため次の `run.py start` が止まる（CTL-02）。`<skill-foundation>` は skill-foundation のディレクトリを指す。

1. 実行中なら `python3 <skill>/scripts/run.py abort --reason <理由>` で止める
2. `dev/spec.json` を直す。手で書く部分（この SKILL.md の「2. 手順」、`scripts/` のスキル固有のスクリプト、`references/`、`assets/examples/`）は直接直す
3. `python3 <skill-foundation>/scripts/render_skill.py --dir <skill>` で生成した部分を作り直す
4. ルールや契約を変えたなら `dev/probes.json` の違反例も合わせ、`python3 <skill-foundation>/scripts/probe.py <skill>` を通す
5. `python3 <skill-foundation>/scripts/skill_lint.py <skill> --final --seal` を通す。通ると指紋を記録し直す
<!-- END GENERATED:control -->
