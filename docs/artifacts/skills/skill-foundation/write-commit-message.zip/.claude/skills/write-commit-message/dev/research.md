# write-commit-message の調査

## git diff の対象

- 確認方法：[git-diff 公式文書](https://git-scm.com/docs/git-diff) の `git diff --cached` の節を 2026-10-28 に確認した。環境の `git --version` は `git: [environment redacted]
- 確認の状態：確認済み
- 分かったこと：`--cached` はステージされた変更を返す。`--no-ext-diff` で外部差分プログラムを使わず、`--no-color` で色の制御文字を出さない。
- 使ったルール：IN-01、IN-02、STEP-01、STEP-02

## メッセージの長さと文字コード

- 確認方法：[git-commit 公式文書](https://git-scm.com/docs/git-commit#_discussion) の DISCUSSION を 2026-10-28 に確認した。
- 確認の状態：確認済み
- 分かったこと：Git の文書は最初の行を50文字以下の短い要約にする書き方を示す。コミットメッセージは通常 UTF-8 で保存される。今回の依頼は日本語1行の UTF-8 テキストを指定しているため、本文は付けない。
- 使ったルール：OUT-01、OUT-02、OUT-03、OUT-04

## CIを止める記法

- 確認方法：[GitHub Docs](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/skip-workflow-runs) を 2026-10-28 に確認した。
- 確認の状態：確認済み
- 分かったこと：文書に記載された skip の文字列を出力しない契約にする。GitHubへの投稿やCIの実行は行わない。
- 使ったルール：OUT-05
