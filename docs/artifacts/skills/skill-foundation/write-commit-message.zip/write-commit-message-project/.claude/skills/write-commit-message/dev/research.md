# write-commit-message の調査

## ステージ済みの差分

- 確認方法：2026-10-28に隔離したgitプロジェクトでsample.txtをstageした後、未stageの変更を加え、`git diff --cached -- sample.txt`を実行した。
- 確認の状態：確認済み
- 分かったこと：stage済みの行だけが返り、未stageの行は返らなかった。`git diff -h`で`--name-only`と`-z`も確認した。
- 使ったルール：IN-01、IN-02、STEP-01、STEP-02、STEP-03

## 依頼の出力条件

- 確認方法：今回の公開サンプルの入力を読んだ（2026-10-28）。
- 確認の状態：確認済み
- 分かったこと：git diffから日本語1行のメッセージをUTF-8テキストに出す。コミットと外部投稿は行わず、収束テストを省く。
- 使ったルール：OUT-01、OUT-02、OUT-03、OUT-04、OUT-05
