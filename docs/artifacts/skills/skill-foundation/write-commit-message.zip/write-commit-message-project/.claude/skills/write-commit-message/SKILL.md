---
name: write-commit-message
description: "ステージ済みの git diff から、日本語1行のコミットメッセージをUTF-8テキストに出す。「git diffから日本語1行のコミットメッセージを書くスキルを作って」、「コミットメッセージを書いて」、「差分から1行のメッセージを作って」、「ステージした変更を日本語で要約して」、「commit messageを書いて」と頼まれたときに使う。コミットの実行やプッシュには使わない（代わりにgit コマンドを使う）。プルリクエストの説明文には使わない（代わりにプルリクエスト用のスキルを使う）。"
---

# コミットメッセージを書く

<!-- BEGIN GENERATED:purpose -->
ステージ済みの git diff から、日本語1行のコミットメッセージをUTF-8テキストに出す
<!-- END GENERATED:purpose -->

## 1. 使う場面

<!-- BEGIN GENERATED:triggers -->
次のような依頼で使う。

- 「git diffから日本語1行のコミットメッセージを書くスキルを作って」
- 「コミットメッセージを書いて」
- 「差分から1行のメッセージを作って」
- 「ステージした変更を日本語で要約して」
- 「commit messageを書いて」

次の場合は使わない。

- コミットの実行やプッシュ → 代わりに: git コマンド
- プルリクエストの説明文 → 代わりに: プルリクエスト用のスキル

依頼の内容から自動で選ばれる。明示して呼ぶときは Claude Code では `/write-commit-message`、Codex では `$write-commit-message` と書く。
<!-- END GENERATED:triggers -->

## 2. 手順

1. start の前に必要な質問を済ませる（CTL-03）。依頼がステージ済みのgit diffを要約するものかを確かめる。コミットやpushの依頼なら、その操作は行わず対象外と返す（IN-01、STEP-03）。
2. `python3 <skill>/scripts/run.py start "<依頼文>"` を実行する（CTL-01）。
3. `python3 <skill>/scripts/collect_diff.py` を実行する。終了コード4ならIN-01、2ならSTEP-04に従ってrun.py abortで中断する。終了コード0なら、返されたステージ済みの差分だけを材料にする（IN-02、STEP-01、STEP-02）。
4. 変更対象と変更動作を日本語で1行にまとめる。50文字以内で行末に句点を付けず、本文と箇条書きとIDは付けない。見本は `assets/examples/commit-message.txt` を読む（OUT-02、OUT-03、OUT-04、OUT-05）。
5. 要約を `.skill-runs/write-commit-message/out/commit-message.txt` にUTF-8で保存する（OUT-01）。
6. `python3 <skill>/scripts/run.py check` を実行し、整形されたときは出力を読み直す。指摘があれば出力を直す（CTL-02）。
7. `python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順6に戻り、0なら出力本文をそのまま返す（RPT-01）。

## 3. 入力

<!-- BEGIN GENERATED:inputs -->
入力の項目は無い。依頼文だけを `run.py start` に渡す。
<!-- END GENERATED:inputs -->

## 4. ルール

<!-- BEGIN GENERATED:decisions -->
| ID | ルール | 守らせ方 |
|---|---|---|
| IN-01 | collect_diff.pyが終了コード4なら、出力を書かずrun.py abort --reason "ステージ済みの変更が無い"を実行する。 | script, doc: scripts/collect_diff.py と SKILL.md の手順3 |
| IN-02 | 読む材料はcollect_diff.pyの出力だけにする。未ステージの変更とコミット履歴は読まない。 | script, review: scripts/collect_diff.py と完了前の差分との照合 |
| STEP-01 | run.py start、collect_diff.py、出力保存、run.py check、run.py finishの順で実行する。 | script, doc: scripts/collect_diff.py と SKILL.md の手順 |
| STEP-02 | collect_diff.pyの終了コードが0なら1行の要約を書き、4ならIN-01で中断する。本文や箇条書きは作らない。 | script, doc: scripts/collect_diff.py の終了コードと SKILL.md の手順3 |
| STEP-03 | スキルが実行するgitはcollect_diff.pyの中のdiffだけにする。git add、git commit、git pushは実行しない。 | doc: SKILL.mdの手順3 |
| STEP-04 | collect_diff.pyが終了コード2なら、理由をrun.py abortへ渡して中断する。 | doc: SKILL.mdの手順3 |
| OUT-01 | 出力は.skill-runs/write-commit-message/out/commit-message.txtの1ファイルにUTF-8で書く。 | validate: outputs.commit-message の件数とパス |
| OUT-02 | 出力は空でない1行にし、見出し、本文、箇条書き、コードブロックを付けない。 | validate: require と max_lines の検査 |
| OUT-03 | 出力は日本語の要約にし、行末の句点は付けない。 | validate, format: 日本語の文字をrequireで確かめ、replaceで行末の句点を消す |
| OUT-04 | 出力の1行は50文字以内にする。 | validate: line_length の max=50 |
| OUT-05 | [skip ci]、[ci skip]、[no ci]、[skip actions]、[actions skip]、skip-checks: trueを書かない。 | validate: forbidでCIを止める記法を検出する |
| RPT-01 | 最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない。中断したときは、`run.py abort` が出力した本文を同じように使う。決めきれなかったことは、finish の前に `.skill-runs/<name>/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを本文の「## 補足」に入れる。 | runtime, validate, review: scripts/run.py の finish と abort が本文を組み立て、.skill-runs/<name>/report.md にも保存する。check と finish が notes.md の形を検査する |
| CTL-01 | 手順の最初に `run.py start`、出力を書いた後に `run.py check`、最後に `run.py finish` を実行する。`finish` が終了コード0で終わるまで、完了と返答しない。 | runtime, validate: scripts/run.py。finish は契約の検査に通らないと終了コード1で終わる |
| CTL-02 | `run.py start` から `run.py finish` までの間、スキルの保護ファイル（`SKILL.md`、`scripts/`、`assets/`、`references/`）と、プロジェクトに登録したこのスキルの hooks を変えない。出力が契約に合わないときは、出力の方を直す。保護ファイルが合格時の指紋（`assets/seal.json`）と違うと `run.py start` が終了コード1で止まるので、そのときは出力された指摘をユーザーに伝えて止まる。 | runtime, validate: scripts/run.py の start が保護ファイルのハッシュと hooks の登録を記録し、check と finish が比べる。`start --restart` は記録を最初の start から引き継ぐ。hooks が編集の前に止める。start は合格時の指紋と保護ファイルを比べ、違えば始めない |
| CTL-03 | ユーザーに聞くことは `run.py start` の前にまとめて聞く。start の後に聞く必要が出たときは、`run.py wait --question <質問>` を実行してから聞く。聞けない状況では既定値を使い、報告の「既定値で決めた値」に載せる。 | runtime, doc: scripts/run.py の start は、聞くべき入力が無いと終了コード3で止まり、質問を出力する。wait は hooks の強制を止める |
| CTL-04 | hooks は、このスキルの実行中（status: active）に、編集の後の検査、応答を終える前の検査、保護ファイルの編集の停止の3つを行う。実行していないときは、合格時の指紋があるスキル（`assets/seal.json` がある）の保護ファイルの編集に、Claude Code で確認を求めることだけを行う。ユーザーの発言を止めたり書き換えたりしない。 | runtime: scripts/hook.py。install.py が Claude Code（.claude/settings.json）と Codex（.codex/hooks.json）に登録する |
| CTL-05 | `run.py start` から `run.py finish` までの間に作る・変えるファイルは、「5. 出力の契約」の出力と `control.allow_changes` に挙げたものだけにする。作業用のメモや一時ファイルも、出力の置き場の外に作らない。 | runtime, validate: scripts/run.py の start が git の作業ツリーの状態を記録し、check と finish が比べる。編集の直後には hooks が知らせる |

#### STEP-02 の場合分け

| 終了コード | 扱い |
|---|---|
| 0 | 日本語1行の要約を書く |
| 4 | IN-01に従って中断する |
| 上のどれでもない | STEP-04に従って中断する |

理由・良い例・悪い例は [references/decisions.md](references/decisions.md) にある。
<!-- END GENERATED:decisions -->

## 5. 出力の契約

<!-- BEGIN GENERATED:contract -->
| 出力 | 置き場 | 件数 | 検査（ルールID） |
|---|---|---|---|
| commit-message コミットメッセージ | `{run}/out/commit-message.txt` | 1〜1 件（OUT-01） | 自動で直す: `。$` を「」に置き換える（OUT-03）。1 行目が `\S` に一致する（OUT-02）。1 行以下（OUT-02）。1 行目が `[ぁ-んァ-ン一-龯]` に一致する（OUT-03）。1行目は 50 文字以下（OUT-04）。`(?i)\[(skip ci\|ci skip\|no ci\|skip actions\|actions skip)\]\|^skip-checks:\s*true` に一致する行が無い（OUT-05） |

`{run}` は実行記録の置き場 `.skill-runs/write-commit-message` を指す。`run.py start` の前からあったファイルで、内容が変わっていないものは検査しない。

- 保護ファイルが実行中に変わっていない（CTL-02）
- 上の出力のほかに、start の後に変わったファイルが無い（CTL-05。git の作業ツリーで判定し、git が無いときは検査しない）
<!-- END GENERATED:contract -->

## 6. 完了前チェックリスト

<!-- BEGIN GENERATED:checklist -->
- [ ] IN-02 読む材料はcollect_diff.pyの出力だけにする。未ステージの変更とコミット履歴は読まない。
- [ ] RPT-01 最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない。中断したときは、`run.py abort` が出力した本文を同じように使う。決めきれなかったことは、finish の前に `.skill-runs/<name>/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを本文の「## 補足」に入れる。
- [ ] `python3 <skill>/scripts/run.py finish` が終了コード0で終わった
<!-- END GENERATED:checklist -->

## 7. 報告

<!-- BEGIN GENERATED:report -->
最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない（RPT-01）。決めきれなかったことは、finish の前に `.skill-runs/write-commit-message/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを「## 補足」に入れる。中断するときは `run.py abort --reason <理由>` を実行し、abort が出力した本文を同じようにそのまま使う。本文の形は次のとおり。

```text
<出力 commit-message の本文>

---

## 結果

write-commit-message: 完了（検証に合格）

## 出力

- `<パス>`（<出力ID> <出力の名前>）

## 既定値で決めた値

- <項目>（<キー>）: <値>（無ければ「- なし」）

## 入力で読めなかった値

- <内容>（無ければ「- なし」）

## 検証

- `run.py finish`: 指摘 0 件

## 補足

- <notes.md の箇条書き。無ければ「- なし」>
```
<!-- END GENERATED:report -->

## 8. 制御の仕組み

<!-- BEGIN GENERATED:control -->
| 仕組み | いつ働くか | 何をするか |
|---|---|---|
| `scripts/run.py start` | 手順の始め | 入力を正規化し（表記ゆれ・全角・未知のキーを受け入れる）、既定値で補い、保護ファイルのハッシュと git の作業ツリーの状態を記録する。保護ファイルが合格時の指紋（`assets/seal.json`）と違えば始めない（終了コード1） |
| `scripts/run.py check` と `finish` | 出力を書いた後と最後 | 契約（`assets/contract.json`）の format で出力を直してから検査する。finish は通ったときだけ実行を終える |
| hooks の pre-tool | ファイルを編集する前 | 保護ファイルと実行記録の編集を止める（Claude Code は確認を求め、Codex は拒否する）。実行していないときも、合格時の指紋があるスキルの保護ファイルの編集に Claude Code で確認を求める |
| hooks の post-tool | ファイルを編集した後 | 出力に当たるファイルを format で直し、検査し、指摘を返す。出力でも変えてよいファイルでもなければ CTL-05 の指摘を返す |
| hooks の stop | 応答を終える前 | 出力全体を検査し、通るまで応答を終えさせない（最大 3 回。超えると status: failed） |
| hooks の prompt | ユーザーが発言したとき | 質問待ち（wait）を解くだけ。発言を止めたり書き換えたりしない |

hooks は、このスキルの実行中（`.skill-runs/write-commit-message/state.json` の status が active）だけ出力を検査する。hooks が無い環境でも、`run.py check` と `finish` が同じ検査をする。

hooks の登録: `python3 <skill>/scripts/install.py --project <プロジェクトのルート>`（Claude Code は `.claude/settings.json`、Codex は `.codex/hooks.json` に追記する。Codex では、追記した hooks を `/hooks` で信頼するまで動かない）

保護ファイル（スキルのディレクトリからの相対パス）: `SKILL.md`、`scripts/**`、`assets/**`、`references/**`

このスキル（ルール、契約、手順、スクリプト）を変えるときは、次の順にする。保護ファイルだけを直接書き換えると、合格時の指紋と違うため次の `run.py start` が止まる（CTL-02）。`<skill-foundation>` は skill-foundation のディレクトリを指す。

1. 実行中なら `python3 <skill>/scripts/run.py abort --reason <理由>` で止める
2. `dev/spec.json` を直す。手で書く部分（この SKILL.md の「2. 手順」、`scripts/` のスキル固有のスクリプト、`references/`、`assets/examples/`）は直接直す
3. `python3 <skill-foundation>/scripts/render_skill.py --dir <skill>` で生成した部分を作り直す
4. ルールや契約を変えたなら `dev/probes.json` の違反例も合わせ、`python3 <skill-foundation>/scripts/probe.py <skill>` を通す
5. `python3 <skill-foundation>/scripts/skill_lint.py <skill> --final --seal` を通す。通ると指紋を記録し直す
<!-- END GENERATED:control -->
