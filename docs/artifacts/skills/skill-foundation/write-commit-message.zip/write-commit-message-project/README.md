# 生成した write-commit-message

このZIPは今回の隔離プロジェクトで生成したSkill・hooks設定・カタログを収録する。`.agents/skills/write-commit-message` はこのプロジェクトではリンクとして生成されたため、ZIPには含めない。利用する場所で、必要な設定差分を確認したうえで次を実行するとリンクとhooksを登録できる。

```sh
python3 .claude/skills/write-commit-message/scripts/install.py --project .
```

既存の設定をZIPの設定で置き換えないこと。Codexのhooksの信頼操作と実製品による自動発火は今回の実行範囲外。収束テストは依頼により省略した。
