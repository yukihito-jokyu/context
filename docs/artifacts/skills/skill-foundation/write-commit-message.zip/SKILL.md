---
name: write-commit-message
description: "ステージ済みの差分とチケットIDから、このリポジトリの形式のコミットメッセージを1つ書く。「コミットメッセージを書いて」、「この変更のコミットメッセージを考えて」、「ステージした内容でコミットメッセージを作って」、「ABC-12 のコミットメッセージをお願い」、「commit message 書いて」と頼まれたときに使う。コミットの実行やプッシュには使わない（代わりにgit コマンドを使う）。プルリクエストの説明文には使わない（代わりにプルリクエスト用のスキルを使う）。"
---

# コミットメッセージを書く

<!-- BEGIN GENERATED:purpose -->
ステージ済みの差分とチケットIDから、このリポジトリの形式のコミットメッセージを1つ書く
<!-- END GENERATED:purpose -->

## 1. 使う場面

<!-- BEGIN GENERATED:triggers -->
次のような依頼で使う。

- 「コミットメッセージを書いて」
- 「この変更のコミットメッセージを考えて」
- 「ステージした内容でコミットメッセージを作って」
- 「ABC-12 のコミットメッセージをお願い」
- 「commit message 書いて」

次の場合は使わない。

- コミットの実行やプッシュ → 代わりに: git コマンド
- プルリクエストの説明文 → 代わりに: プルリクエスト用のスキル

依頼の内容から自動で選ばれる。明示して呼ぶときは Claude Code では `/write-commit-message`、Codex では `$write-commit-message` と書く。
<!-- END GENERATED:triggers -->

## 2. 手順

このファイルがあるディレクトリを `<skill>` と呼ぶ。スクリプトは Python 3.9 以上の標準ライブラリだけで動く。手順は番号の順に行い、飛ばさない。

1. 依頼から「3. 入力」の項目を読み取る。表で「start の前に聞く」とある項目が依頼に無ければ、ここでまとめてユーザーに聞く（CTL-03）
2. `python3 <skill>/scripts/run.py start --set ticket=<チケットID> "<依頼文>"` を実行する。終了コード3なら、出力された質問をユーザーに聞き、答えを `--set` で渡してやり直す（CTL-01）
3. `python3 <skill>/scripts/collect_diff.py` を実行する。終了コード4なら IN-01、終了コード2なら STEP-04 に従って中断する。出力に出たファイルと差分だけを材料にする。git はこのスクリプトの中だけで使い、`git add`・`git commit` を実行しない（IN-02、STEP-01、STEP-03）
4. 1行目を `<チケットID> <要約>` の形で書く。チケットIDは start が出した `ticket` の値を使い、要約は「<対象>を<動詞>する」の形にする。`[skip ci]` のような CI を止める記法は書かない（OUT-02、OUT-03、OUT-04、OUT-05、OUT-06）
5. 2行目を空行にし、3行目から本文を、collect_diff.py が出した「本文の単位」と STEP-02 の場合分けに従って書く。形は見本 `assets/examples/commit-message.txt` と同じにする。書いたものを `.skill-runs/write-commit-message/out/commit-message.txt` に保存する（OUT-01、STEP-02）
6. `python3 <skill>/scripts/run.py check` を実行する。「整形」で始まる行は check が契約の format で自動で直した記録なので、ファイルを読み直す。指摘があれば、ルールIDを「4. ルール」で引いて出力を直す
7. 決めきれなかったことがあれば `.skill-runs/write-commit-message/notes.md` に「- 」の箇条書きで書き、`python3 <skill>/scripts/run.py finish` を実行する。終了コード1なら手順6に戻る。終了コード0なら、出力された本文をそのまま返答する（RPT-01）

## 3. 入力

<!-- BEGIN GENERATED:inputs -->
| 項目 | キー | 受け付ける書き方 | 無いとき |
|---|---|---|---|
| チケットID | `ticket` | 文字列（大文字に揃える）。別名: チケット、課題、issue、ticket id | start の前に聞く: チケットID（例: ABC-123）は？ |

入力は `run.py start --set <キー>=<値>` で渡す。キーは表のキー・項目名・別名のどれでもよく、全角と半角、大文字と小文字、`-`・`_`・空白の違いは吸収される。契約に無いキーは無視して記録する。依頼文そのものは最後の引数に渡す。依頼文の中の「キー: 値」の行も読む。
<!-- END GENERATED:inputs -->

## 4. ルール

<!-- BEGIN GENERATED:decisions -->
| ID | ルール | 守らせ方 |
|---|---|---|
| IN-01 | `scripts/collect_diff.py` が終了コード4で終わったら、出力を書かずに `run.py abort --reason "ステージされた変更が無い"` を実行し、変更をステージしてから頼み直すよう返答する。 | script, doc: scripts/collect_diff.py は、ステージされた変更が無いと終了コード4で終わる。中断の仕方は SKILL.md の手順3 |
| IN-02 | 材料は `scripts/collect_diff.py` の出力だけにする。未ステージの変更、コミット履歴、差分に無いファイルの中身は読まない。 | script, review: scripts/collect_diff.py が `git diff --cached` の結果だけを出す。完了前チェックリストで、書いた変更が差分にあるかを確かめる |
| STEP-01 | 手順は `collect_diff.py` → 1行目 → 本文 → `run.py check` → `run.py finish` の順にする。本文の単位（なし・ファイル・ディレクトリ）は、`collect_diff.py` が出した「本文の単位」に従う。 | script, doc: scripts/collect_diff.py が「ファイルの数」と「本文の単位」を出力する。順序は SKILL.md の手順3〜7 |
| STEP-02 | 本文の箇条書きは次の表に従い、パスの昇順に並べる。 | validate, script: scripts/check_body.py が、箇条書きとステージされたファイルを突き合わせる（契約の command 検査） |
| STEP-03 | 使う git コマンドは、`scripts/collect_diff.py` の中の `git diff --cached` だけにする。`git add`・`git commit`・`git push` を実行しない。 | doc: SKILL.md の手順3（読むのは collect_diff.py の出力だけ） |
| STEP-04 | `scripts/collect_diff.py` が終了コード2で終わったら、出力を書かずに `run.py abort --reason "<エラーの1行目>"` を実行し、エラーの内容を返答する。 | doc: SKILL.md の手順3 |
| OUT-01 | メッセージは `.skill-runs/write-commit-message/out/commit-message.txt` に1ファイルだけ書く。ほかの場所にファイルを作らない。 | validate: 契約の outputs.message の path と count（1件） |
| OUT-02 | 1行目は `<チケットID> <要約>`、2行目は空行、3行目から本文（STEP-02）にする。Conventional Commits の接頭辞（`feat:` の類）を付けない。 | validate: 契約の checks（1行目の形、2行目が空、接頭辞の禁止） |
| OUT-03 | 要約と本文の変更の要約は日本語で、「<対象>を<動詞>する」の形で書き、行末に `。` を付けない。 | format, review: 契約の format（行末の `。` を消す）。完了前チェックリストで、日本語の「<対象>を<動詞>する」の形かを確かめる |
| OUT-04 | 1行目の先頭には、入力 `ticket` の値（start が大文字に揃えたもの）を書く。依頼文や差分からチケットIDを推測しない。 | validate: 契約の checks（1行目が `{in:ticket}` で始まる） |
| OUT-05 | 1行目は、チケットIDと空白を含めて50文字以内にする。 | validate: 契約の checks（1行目の長さ） |
| OUT-06 | メッセージに、CI の実行を止める記法（`[skip ci]`、`[ci skip]`、`[no ci]`、`[skip actions]`、`[actions skip]`、`skip-checks: true` の行）を書かない。 | validate: 契約の checks（CI を止める記法の禁止） |
| RPT-01 | 最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない。中断したときは、`run.py abort` が出力した本文を同じように使う。決めきれなかったことは、finish の前に `.skill-runs/<name>/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを本文の「## 補足」に入れる。 | runtime, validate, review: scripts/run.py の finish と abort が本文を組み立て、.skill-runs/<name>/report.md にも保存する。check と finish が notes.md の形を検査する |
| CTL-01 | 手順の最初に `run.py start`、出力を書いた後に `run.py check`、最後に `run.py finish` を実行する。`finish` が終了コード0で終わるまで、完了と返答しない。 | runtime, validate: scripts/run.py。finish は契約の検査に通らないと終了コード1で終わる |
| CTL-03 | ユーザーに聞くことは `run.py start` の前にまとめて聞く。start の後に聞く必要が出たときは、`run.py wait --question <質問>` を実行してから聞く。聞けない状況では既定値を使い、報告の「既定値で決めた値」に載せる。 | runtime, doc: scripts/run.py の start は、聞くべき入力が無いと終了コード3で止まり、質問を出力する。wait は hooks の強制を止める |
| CTL-04 | hooks は実行中（status: active）に、編集の後と応答を終える前に出力を検査する。実行記録への直接の編集は拒否する。ユーザーの発言を止めたり書き換えたりしない。hooks が無くても run.py check と finish で同じ出力の検査を行う。 | runtime: scripts/hook.py。install.py が Claude Code（.claude/settings.json）と Codex（.codex/hooks.json）に登録する |

#### STEP-02 の場合分け

| ステージされたファイルの数 | 本文 |
|---|---|
| 1 | 書かない（1行目だけ） |
| 2〜5 | ファイルごとに「- `<パス>`: <変更の要約>」を1行 |
| 6以上 | ディレクトリごとに「- `<ディレクトリ>/`: <変更の要約>」を1行 |
| 上のどれでもない（0） | IN-01 に従い、書かずに中断する |

理由・良い例・悪い例は [references/decisions.md](references/decisions.md) にある。
<!-- END GENERATED:decisions -->

## 5. 出力の契約

<!-- BEGIN GENERATED:contract -->
| 出力 | 置き場 | 件数 | 検査（ルールID） |
|---|---|---|---|
| commit-message コミットメッセージ | `{run}/out/commit-message.txt` | 1〜1 件（OUT-01） | 自動で直す: `。$` を「」に置き換える（OUT-03）。1 行目が `^[A-Z][A-Z0-9]*-\d+ \S` に一致する（1行目は「チケットID 要約」）（OUT-02）。2 行目が `\S` に一致しない（2行目は空行）（OUT-02）。1 行目が `^[A-Z][A-Z0-9]*-\d+ (feat\|fix\|chore\|docs\|refactor\|test\|style\|perf\|build\|ci)(\(.*\))?!?:` に一致しない（Conventional Commits の接頭辞を付けない）（OUT-02）。1 行目が `^{in:ticket} ` に一致する（入力のチケットIDで始める）（OUT-04）。1行目は 50 文字以下（OUT-05）。`(?i)\[(skip ci\|ci skip\|no ci\|skip actions\|actions skip)\]\|^skip-checks:\s*true` に一致する行が無い（CI を止める記法を書かない）（OUT-06）。`python3 {skill}/scripts/check_body.py {file}` が通る（STEP-02） |

`{run}` は実行記録の置き場 `.skill-runs/write-commit-message` を指す。`run.py start` の前からあったファイルで、内容が変わっていないものは検査しない。

<!-- END GENERATED:contract -->

## 6. 完了前チェックリスト

<!-- BEGIN GENERATED:checklist -->
- [ ] IN-02 材料は `scripts/collect_diff.py` の出力だけにする。未ステージの変更、コミット履歴、差分に無いファイルの中身は読まない。
- [ ] OUT-03 要約と本文の変更の要約は日本語で、「<対象>を<動詞>する」の形で書き、行末に `。` を付けない。
- [ ] RPT-01 最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない。中断したときは、`run.py abort` が出力した本文を同じように使う。決めきれなかったことは、finish の前に `.skill-runs/<name>/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを本文の「## 補足」に入れる。
- [ ] `python3 <skill>/scripts/run.py finish` が終了コード0で終わった
<!-- END GENERATED:checklist -->

## 7. 報告

<!-- BEGIN GENERATED:report -->
最終の返答は、`run.py finish` が出力した本文をそのまま使い、前後に文を足さず、要約しない（RPT-01）。決めきれなかったことは、finish の前に `.skill-runs/write-commit-message/notes.md` に「- 」で始まる箇条書きで書く（10 項目まで）。finish がそれを「## 補足」に入れる。中断するときは `run.py abort --reason <理由>` を実行し、abort が出力した本文を同じようにそのまま使う。本文の形は次のとおり。

```text
<出力 commit-message の本文>

---

## 結果

write-commit-message: 完了（検証に合格）

## 出力

- `<パス>`（<出力ID> <出力の名前>）

## 既定値で決めた値

- <項目>（<キー>）: <値>（無ければ「- なし」）

## 入力で読めなかった値

- <内容>（無ければ「- なし」）

## 検証

- `run.py finish`: 指摘 0 件

## 補足

- <notes.md の箇条書き。無ければ「- なし」>
```
<!-- END GENERATED:report -->

## 8. 制御の仕組み

<!-- BEGIN GENERATED:control -->
| 仕組み | いつ働くか | 何をするか |
|---|---|---|
| `scripts/run.py start` | 手順の始め | 入力を正規化し（表記ゆれ・全角・未知のキーを受け入れる）、既定値で補い、実行記録を作る |
| `scripts/run.py check` と `finish` | 出力を書いた後と最後 | 契約（`assets/contract.json`）の format で出力を直してから検査する。finish は通ったときだけ実行を終える |
| hooks の pre-tool | ファイルを編集する前 | 実行記録への直接の編集を拒否する。スキル自身のファイルは編集できる |
| hooks の post-tool | ファイルを編集した後 | 出力に当たるファイルを format で直し、検査し、指摘を返す |
| hooks の stop | 応答を終える前 | 実行中は出力全体を検査する（最大 3 回。超えると status: failed） |
| hooks の prompt | ユーザーが発言したとき | 質問待ちを解く。発言を止めたり書き換えたりしない |

出力の検査は実行中（`.skill-runs/write-commit-message/state.json` の status が active）に働く。hooks が無い環境でも、`run.py check` と `finish` が同じ検査をする。

hooks の登録: `python3 <skill>/scripts/install.py --project <プロジェクトのルート>`（Claude Code は `.claude/settings.json`、Codex は `.codex/hooks.json` に追記する。Codex では、追記した hooks を `/hooks` で信頼するまで動かない）
<!-- END GENERATED:control -->
