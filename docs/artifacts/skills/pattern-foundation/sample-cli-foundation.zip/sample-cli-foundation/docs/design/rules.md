# sample-cli-foundation のルール

このファイルは sample-cli-foundation のルールの正本である。AGENTS.md・スキル・レビューの指摘・検査のエラーは、ここのルールIDを参照する。ルールの変更手順は AGENTS.md の「ルールを変えたいとき」に従う。

## 読み方

- ルールIDは `<接頭辞>-<連番>` である。廃止したルールも ID を再利用せず、`- 状態: 廃止` と書いて残す
- **強制**の先頭のキーワードは、そのルールを守らせる仕組みを表す

  | キーワード | 仕組み |
  |---|---|
  | `type` | 型・可視性で書けなくする |
  | `format` | formatter |
  | `lint` | linter |
  | `structure` | 構造検査 |
  | `test` | テスト |
  | `generator` | 生成器 |
  | `review` | レビュー用スキル |
  | `doc` | 文書のみ |

  ルールと仕組みの対応表は `enforcement-matrix.md`（生成物）にある
- `type`・`format`・`lint`・`structure`・`test` のルールには、違反例（probe）が `.foundation/probes.json` にあり、検査で落ちることを確かめてある

## ルールの書式

`rules_check.py` がこの書式を読む。項目名と順番を変えない。

```markdown
### <接頭辞>-<2桁の番号> <決定を1行で要約した題名>

- 軸: <答えている軸の記号。複数ならカンマ区切り>
- 決定: <読んだ2人が同じ判定をできる1文。条件で答えが変わるなら、次の行から2字下げで決定表を書く>
- 理由: <何が揺れ、何が壊れるのを防ぐか>
- 出典: <research.md の該当節、または公式ドキュメントの URL。無ければ行ごと省く>
- 強制: <キーワード。複数ならカンマ区切り> — <仕組みの説明：どの設定・スクリプトのどこで縛るか>
- probe: <この強制を証明する probe の ID。機械の段ごとに1件以上>
- 良い例:
  <5行以内のコード。長くなるなら「見本: <参照実装のパス>」と書く>
- 悪い例:
  <実際に書かれがちな違反。5行以内>
```

- 機械の段（`type`・`format`・`lint`・`structure`・`test`）を含まないルールには、`- 機械化しない理由:` を**強制**の次の行に足し、`probe` の値は `なし` にする
- 軸の記号は範囲で書いてもよい（`D1〜D3` は D1、D2、D3 と読まれる）
- 番号は節ごとに 01 から、カタログの軸の順（同じ軸の中では決定の順）に振る
- ルールが0件の節は、見出しごと消し、その節の軸を「対象外とした軸」表に書く
- 決定の中のコード片（`` ` `` で囲んだ部分）は、あいまいな語の検査から除かれる

## 用語

| 用語 | 意味 |
|---|---|
| TODO(pattern-foundation) | この基盤で使う用語を定義する |

## 追加した軸

カタログに無い、この分野に固有の軸を定義する。domain-profiles.md がその分野に定めた X 軸はすべて載せる。無ければ表を空のまま残す。

| 軸 | 内容 | 置く節 |
|---|---|---|

## STR 配置と構造

TODO(pattern-foundation): ルールを書く

## DEP 境界と依存

TODO(pattern-foundation): ルールを書く

## NAM 命名

TODO(pattern-foundation): ルールを書く

## CODE 書き方

TODO(pattern-foundation): ルールを書く

## ERR エラーと入力検証

TODO(pattern-foundation): ルールを書く

## STATE 状態とデータの流れ

TODO(pattern-foundation): ルールを書く

## ASYNC 非同期と並行

TODO(pattern-foundation): ルールを書く

## OPS ログ・設定・セキュリティ・表示

TODO(pattern-foundation): ルールを書く

## TEST テスト

TODO(pattern-foundation): ルールを書く

## PROC 作業手順

TODO(pattern-foundation): ルールを書く。波及の対応表（一緒に変えるファイルの組）はここに置く

## TOOL 道具と自動化

TODO(pattern-foundation): ルールを書く。抑止コメントの禁止、保護ファイル、自動実行はここに置く

## 対象外とした軸

揺れない軸、またはこの分野に無い軸と、その理由を書く。

| 軸 | 理由 |
|---|---|
