# sample-cli-foundation 収束テストの記録

独立エージェント（この基盤の作成時の会話履歴を持たないセッション）に同じ課題を解かせ、書き方の違い（揺れ）を測った記録である。手順の詳細は、作成に使ったスキルの convergence-test.md にある。各ラウンドの生データは `.foundation/convergence/round-<R>/` にある。

## 条件

| 項目 | 値 |
|---|---|
| 実行方法 | TODO(pattern-foundation): `claude -p` か Agent ツールか、と主な起動オプション |
| エージェントの人数 | |
| 課題 | `.foundation/convergence/tasks.json` |
| 合格基準 | |

## ラウンドの一覧

| ラウンド | 課題 | files | names | content | check | R1〜R6 の未対処 |
|---|---|---|---|---|---|---|
| TODO(pattern-foundation) | | | | | | |

## ラウンド 1

### 揺れと分類

| # | 課題 | 揺れ | 分類 | 対処 |
|---|---|---|---|---|
| TODO(pattern-foundation) | | | | |

## レビュー検出率

| エージェント | 検出率 | 余計な指摘 | 判定 |
|---|---|---|---|
| TODO(pattern-foundation) | | | |

## 結論

TODO(pattern-foundation): 合格基準を満たしたか、満たさなかった場合は残った揺れと、その扱いを書く。
