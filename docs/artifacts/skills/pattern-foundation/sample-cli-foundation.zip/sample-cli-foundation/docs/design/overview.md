# sample-cli-foundation 設計の概要

## ゴール

この基盤のゴールは、同じ依頼を受けた別々の作者（人・エージェント）が、同じ書き方をする状態を保つことである。あわせて、変更が局所に収まる構造にすることを目指す。

TODO(pattern-foundation): 依頼の要点（何のための基盤か）を書き足す。

## 前提

### 受けた指示

TODO(pattern-foundation): ユーザーの指示の要点と、指定された技術・ツールを書く。

### 既定値で決めた事項

TODO(pattern-foundation): 指示に無く、既定値で決めた事項と ADR へのリンクを書く。無ければ「なし」と書く。

## 全体像

| 技術 | バージョン | 役割 |
|---|---|---|
| TODO(pattern-foundation) | | |

TODO(pattern-foundation): 層・データの流れを数行で説明する。詳しくは architecture.md に書く。

## ルールを守らせる仕組み

この基盤では、ルールを次の3段で守らせる。

1. **決める**：書き方が分かれうる点ごとに答えを1つ決め、ルールIDを付けて `rules.md` に書いた
2. **縛る**：ルールをできるだけ機械（型、formatter、linter、構造検査、テスト）で強制し、違反例（probe）で効いていることを確かめた。どのルールをどの仕組みで縛っているかは `enforcement-matrix.md` にある
3. **測る**：この基盤を初めて見る独立エージェントに同じ課題を解かせ、書き方の違いを測ってルールを締め込んだ。経過は `convergence-report.md` にある

## 読む順番

1. この文書
2. [architecture.md](architecture.md)：構造と、その理由
3. [rules.md](rules.md)：ルールの全文
4. [enforcement-matrix.md](enforcement-matrix.md)：ルールと検査の対応
5. [research.md](research.md)：技術の調査と出典
6. [adr/](adr/)：主な決定の記録
7. [convergence-report.md](convergence-report.md)：収束テストの結果
