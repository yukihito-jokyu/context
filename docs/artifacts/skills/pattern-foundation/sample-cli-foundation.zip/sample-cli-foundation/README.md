# sample-cli-foundation

TODO(pattern-foundation): この基盤が何かを1〜2文で書く。

## はじめに

TODO(pattern-foundation): 依存の導入から check が通るまでのコマンドを、順番に書く。

```bash
python3 scripts/check.py
```

## エージェントと一緒に使う

このディレクトリで Claude Code を起動する。起動すると、`CLAUDE.md`（`AGENTS.md` を読み込む）と、`.claude/skills/` の実装用スキル `impl` とレビュー用スキル `review` が読み込まれ、編集のたびに hooks が整形と lint を走らせる。親のディレクトリで起動すると、hooks が動かない。

## 設計ドキュメント

`docs/design/overview.md` から読む。ルールの全文は `docs/design/rules.md`、ルールと検査の対応は `docs/design/enforcement-matrix.md` にある。
